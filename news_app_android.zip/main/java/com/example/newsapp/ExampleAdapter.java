package com.example.newsapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ExampleAdapter extends RecyclerView.Adapter<ExampleAdapter.ExampleViewHolder> {
    private Context mContext;
    private ArrayList<PostClass> mExampleList;
    private OnItemClickListener mListener;

    public interface OnItemClickListener{
        void onItemClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        mListener = listener;
    }

    public ExampleAdapter(Context Context, ArrayList<PostClass> ExampleList) {
        this.mContext = Context;
        this.mExampleList = ExampleList;
    }

    @NonNull
    @Override
    public ExampleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.post_design, parent, false);
        return new ExampleViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ExampleViewHolder holder, int position) {
        PostClass currentItem = mExampleList.get(position);

         String Author = currentItem.getmAuthor();
         String Title = currentItem.getmTitle();
         String Description = currentItem.getmDescription();
         String Url = currentItem.getmUrl();
         String UrlToImage = currentItem.getmUrlToImage();
         String PublishedAt = currentItem.getmPublishedAt();
         String Content = currentItem.getmContent();

         holder.mTextViewTitle.setText(Title);
         holder.mTextViewPublishedAt.setText(PublishedAt);
         holder.mTextViewDescription.setText(Description);

        Picasso.with(mContext).load(UrlToImage).fit().centerInside().into(holder.mImageView);
    }

    @Override
    public int getItemCount() {
        return mExampleList.size();
    }

    public class ExampleViewHolder extends RecyclerView.ViewHolder{
        public ImageView mImageView;
        public TextView mTextViewTitle;
        public TextView mTextViewDescription;
        public TextView mTextViewPublishedAt;

        public ExampleViewHolder(@NonNull View itemView) {
            super(itemView);
            mImageView = itemView.findViewById(R.id.post_image1);
            mTextViewTitle = itemView.findViewById(R.id.post_title2);
            mTextViewDescription = itemView.findViewById(R.id.post_description3);
            mTextViewPublishedAt = itemView.findViewById(R.id.post_publishedAt);



            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mListener != null){
                        int position = getAdapterPosition();

                        if (position != RecyclerView.NO_POSITION){
                            mListener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }
}
