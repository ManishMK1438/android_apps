package com.example.newsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toolbar;

import com.eyalbira.loadingdots.LoadingDots;
import com.github.lzyzsd.circleprogress.CircleProgress;
import com.squareup.picasso.Picasso;

import static com.example.newsapp.MainActivity.EXTRA_CONTENT;
import static com.example.newsapp.MainActivity.EXTRA_PUBLISHED_AT;
import static com.example.newsapp.MainActivity.EXTRA_TITLE;
import static com.example.newsapp.MainActivity.EXTRA_URL;

public class DetailActivity extends AppCompatActivity {

    private LoadingDots loadingDots;
    private ImageView imageViewDesc;
    private TextView textViewTitle;
    private TextView textViewPublishedAt;
    private TextView textViewContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Initialization();

        Intent intent = getIntent();
        String imageURL = intent.getStringExtra(EXTRA_URL);
        String title = intent.getStringExtra(EXTRA_TITLE);
        String publishedAt = intent.getStringExtra(EXTRA_PUBLISHED_AT);
        String content = intent.getStringExtra(EXTRA_CONTENT);

        textViewTitle.setText(title);
        textViewPublishedAt.setText(publishedAt);
        textViewContent.setText(content);

        Picasso.with(this).load(imageURL).fit().centerInside().into(imageViewDesc);

        loadingDots.setVisibility(View.INVISIBLE);
    }

    private void Initialization() {
        loadingDots = findViewById(R.id.loading_dots_detail);
        imageViewDesc = findViewById(R.id.imageViewDetail);
        textViewTitle = findViewById(R.id.text_view_title);
        textViewPublishedAt = findViewById(R.id.text_view_publishedAt);
        textViewContent = findViewById(R.id.text_view_Content);
    }
}