package com.example.newsapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.eyalbira.loadingdots.LoadingDots;
import com.google.android.material.navigation.NavigationView;
import com.google.gson.JsonArray;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static com.example.newsapp.CategoriesClass.EXTRA_BUSINESS;
import static com.example.newsapp.CategoriesClass.EXTRA_ENTERTAINMENT;
import static com.example.newsapp.CategoriesClass.EXTRA_GENERAL;
import static com.example.newsapp.CategoriesClass.EXTRA_HEALTH;
import static com.example.newsapp.CategoriesClass.EXTRA_SCIENCE;
import static com.example.newsapp.CategoriesClass.EXTRA_SPORTS;
import static com.example.newsapp.CategoriesClass.EXTRA_TECHNOLOGY;

public class MainActivity extends AppCompatActivity implements ExampleAdapter.OnItemClickListener {
    public static final String EXTRA_URL = "imageURL";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_PUBLISHED_AT = "publishedAt";
    public static final String EXTRA_CONTENT = "content";

    private DrawerLayout drawerLayout;
    private Toolbar toolbar;
    private ActionBarDrawerToggle actionBarDrawerToggle;
    private NavigationView navigationView;

    private RecyclerView mRecyclerView;
    private ExampleAdapter mExampleAdapter;
    private ArrayList<PostClass> mExampleList;
    private RequestQueue mRequestQueue;

    private LoadingDots loadingDots;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SetUpToolbar();

        loadingDots = findViewById(R.id.loading_dots);

        SetUpNavigationView();

        mRecyclerView = findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        mExampleList = new ArrayList<>();

        mRequestQueue = Volley.newRequestQueue(this);



        Intent intent = getIntent();
        boolean business = intent.getBooleanExtra(EXTRA_BUSINESS,false);
        boolean entertainment = intent.getBooleanExtra(EXTRA_ENTERTAINMENT, false);
        boolean general = intent.getBooleanExtra(EXTRA_GENERAL, false);
        boolean health = intent.getBooleanExtra(EXTRA_HEALTH, false);
        boolean science = intent.getBooleanExtra(EXTRA_SCIENCE, false);
        boolean sports = intent.getBooleanExtra(EXTRA_SPORTS, false);
        boolean technology = intent.getBooleanExtra(EXTRA_TECHNOLOGY, false);

        if (!business && !entertainment && !general && !health && !science && !sports && !technology) {
            ParseJSON();
        }

        if (business){
            BusinessParseJSON();

        }else if (entertainment){
            EntertainmentParseJSON();

        }else if (general){
            GeneralParseJSON();

        }else if (health){
            HealthParseJSON();

        }else if (science){
            ScienceParseJSON();

        }else if (sports){
            SportsParseJSON();

        }else if (technology){
            TechnologyParseJSON();

        }

    }

    private void TechnologyParseJSON() {
        String url = "https://newsapi.org/v2/top-headlines?category=technology&apiKey=9a4474c16b464c7d92728072a010f341";

        final JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    JSONArray array = response.getJSONArray("articles");

                    for (int i = 0; i < array.length(); i++){
                        JSONObject article = array.getJSONObject(i);

                        String title = article.getString("title");
                        String description = article.getString("description");
                        String imageURL = article.getString("urlToImage");

                        String author = article.getString("author");
                        String url = article.getString("url");
                        String publishedAt = article.getString("publishedAt");
                        String content = article.getString("content");

                        mExampleList.add(new PostClass(author, title, description, url, imageURL, publishedAt, content));
                    }

                    mExampleAdapter = new ExampleAdapter(MainActivity.this,mExampleList);
                    mRecyclerView.setAdapter(mExampleAdapter);
                    mExampleAdapter.setOnItemClickListener(MainActivity.this);

                    loadingDots.setVisibility(View.INVISIBLE);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("ERROR", "onErrorResponse: "+ error);
            }
        });

        mRequestQueue.add(request);
    }

    private void SportsParseJSON() {
        String url = "https://newsapi.org/v2/top-headlines?category=sports&apiKey=9a4474c16b464c7d92728072a010f341";

        final JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    JSONArray array = response.getJSONArray("articles");

                    for (int i = 0; i < array.length(); i++){
                        JSONObject article = array.getJSONObject(i);

                        String title = article.getString("title");
                        String description = article.getString("description");
                        String imageURL = article.getString("urlToImage");

                        String author = article.getString("author");
                        String url = article.getString("url");
                        String publishedAt = article.getString("publishedAt");
                        String content = article.getString("content");

                        mExampleList.add(new PostClass(author, title, description, url, imageURL, publishedAt, content));
                    }

                    mExampleAdapter = new ExampleAdapter(MainActivity.this,mExampleList);
                    mRecyclerView.setAdapter(mExampleAdapter);
                    mExampleAdapter.setOnItemClickListener(MainActivity.this);

                    loadingDots.setVisibility(View.INVISIBLE);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("ERROR", "onErrorResponse: "+ error);
            }
        });

        mRequestQueue.add(request);
    }

    private void ScienceParseJSON() {
        String url = "https://newsapi.org/v2/top-headlines?category=science&apiKey=9a4474c16b464c7d92728072a010f341";

        final JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    JSONArray array = response.getJSONArray("articles");

                    for (int i = 0; i < array.length(); i++){
                        JSONObject article = array.getJSONObject(i);

                        String title = article.getString("title");
                        String description = article.getString("description");
                        String imageURL = article.getString("urlToImage");

                        String author = article.getString("author");
                        String url = article.getString("url");
                        String publishedAt = article.getString("publishedAt");
                        String content = article.getString("content");

                        mExampleList.add(new PostClass(author, title, description, url, imageURL, publishedAt, content));
                    }

                    mExampleAdapter = new ExampleAdapter(MainActivity.this,mExampleList);
                    mRecyclerView.setAdapter(mExampleAdapter);
                    mExampleAdapter.setOnItemClickListener(MainActivity.this);

                    loadingDots.setVisibility(View.INVISIBLE);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("ERROR", "onErrorResponse: "+ error);
            }
        });

        mRequestQueue.add(request);
    }

    private void HealthParseJSON() {
        String url = "https://newsapi.org/v2/top-headlines?category=health&apiKey=9a4474c16b464c7d92728072a010f341";

        final JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    JSONArray array = response.getJSONArray("articles");

                    for (int i = 0; i < array.length(); i++){
                        JSONObject article = array.getJSONObject(i);

                        String title = article.getString("title");
                        String description = article.getString("description");
                        String imageURL = article.getString("urlToImage");

                        String author = article.getString("author");
                        String url = article.getString("url");
                        String publishedAt = article.getString("publishedAt");
                        String content = article.getString("content");

                        mExampleList.add(new PostClass(author, title, description, url, imageURL, publishedAt, content));
                    }

                    mExampleAdapter = new ExampleAdapter(MainActivity.this,mExampleList);
                    mRecyclerView.setAdapter(mExampleAdapter);
                    mExampleAdapter.setOnItemClickListener(MainActivity.this);

                    loadingDots.setVisibility(View.INVISIBLE);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("ERROR", "onErrorResponse: "+ error);
            }
        });

        mRequestQueue.add(request);
    }

    private void GeneralParseJSON() {
        String url = "https://newsapi.org/v2/top-headlines?category=general&apiKey=9a4474c16b464c7d92728072a010f341";

        final JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    JSONArray array = response.getJSONArray("articles");

                    for (int i = 0; i < array.length(); i++){
                        JSONObject article = array.getJSONObject(i);

                        String title = article.getString("title");
                        String description = article.getString("description");
                        String imageURL = article.getString("urlToImage");

                        String author = article.getString("author");
                        String url = article.getString("url");
                        String publishedAt = article.getString("publishedAt");
                        String content = article.getString("content");

                        mExampleList.add(new PostClass(author, title, description, url, imageURL, publishedAt, content));
                    }

                    mExampleAdapter = new ExampleAdapter(MainActivity.this,mExampleList);
                    mRecyclerView.setAdapter(mExampleAdapter);
                    mExampleAdapter.setOnItemClickListener(MainActivity.this);

                    loadingDots.setVisibility(View.INVISIBLE);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("ERROR", "onErrorResponse: "+ error);
            }
        });

        mRequestQueue.add(request);

    }


    private void EntertainmentParseJSON() {
        String url = "https://newsapi.org/v2/top-headlines?category=entertainment&apiKey=9a4474c16b464c7d92728072a010f341";

        final JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    JSONArray array = response.getJSONArray("articles");

                    for (int i = 0; i < array.length(); i++){
                        JSONObject article = array.getJSONObject(i);

                        String title = article.getString("title");
                        String description = article.getString("description");
                        String imageURL = article.getString("urlToImage");

                        String author = article.getString("author");
                        String url = article.getString("url");
                        String publishedAt = article.getString("publishedAt");
                        String content = article.getString("content");

                        mExampleList.add(new PostClass(author, title, description, url, imageURL, publishedAt, content));
                    }

                    mExampleAdapter = new ExampleAdapter(MainActivity.this,mExampleList);
                    mRecyclerView.setAdapter(mExampleAdapter);
                    mExampleAdapter.setOnItemClickListener(MainActivity.this);

                    loadingDots.setVisibility(View.INVISIBLE);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("ERROR", "onErrorResponse: "+ error);
            }
        });

        mRequestQueue.add(request);

    }

    private void BusinessParseJSON() {
        String url = "https://newsapi.org/v2/top-headlines?category=business&apiKey=9a4474c16b464c7d92728072a010f341";

        final JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    JSONArray array = response.getJSONArray("articles");

                    for (int i = 0; i < array.length(); i++){
                        JSONObject article = array.getJSONObject(i);

                        String title = article.getString("title");
                        String description = article.getString("description");
                        String imageURL = article.getString("urlToImage");

                        String author = article.getString("author");
                        String url = article.getString("url");
                        String publishedAt = article.getString("publishedAt");
                        String content = article.getString("content");

                        mExampleList.add(new PostClass(author, title, description, url, imageURL, publishedAt, content));
                    }

                    mExampleAdapter = new ExampleAdapter(MainActivity.this,mExampleList);
                    mRecyclerView.setAdapter(mExampleAdapter);
                    mExampleAdapter.setOnItemClickListener(MainActivity.this);

                    loadingDots.setVisibility(View.INVISIBLE);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("ERROR", "onErrorResponse: "+ error);
            }
        });

        mRequestQueue.add(request);
    }

    private void ParseJSON() {
        String url = "https://newsapi.org/v2/top-headlines?country=in&apiKey=9a4474c16b464c7d92728072a010f341";

        final JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    JSONArray array = response.getJSONArray("articles");

                    for (int i = 0; i < array.length(); i++){
                        JSONObject article = array.getJSONObject(i);

                        String title = article.getString("title");
                        String description = article.getString("description");
                        String imageURL = article.getString("urlToImage");

                        String author = article.getString("author");
                        String url = article.getString("url");
                        String publishedAt = article.getString("publishedAt");
                        String content = article.getString("content");

                        mExampleList.add(new PostClass(author, title, description, url, imageURL, publishedAt, content));
                    }

                    mExampleAdapter = new ExampleAdapter(MainActivity.this,mExampleList);
                    mRecyclerView.setAdapter(mExampleAdapter);
                    mExampleAdapter.setOnItemClickListener(MainActivity.this);

                    loadingDots.setVisibility(View.INVISIBLE);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("ERROR", "onErrorResponse: "+ error);
            }
        });

        mRequestQueue.add(request);
    }

    private void SetUpNavigationView() {
        navigationView = findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){

                    case R.id.home_nav:
                        ParseJSON();
                        break;

                    case R.id.categories:
                        startActivity(new Intent(MainActivity.this, CategoriesClass.class));
                        break;

                    case R.id.settings:
                        Toast.makeText(MainActivity.this, "settings", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.contact_us:
                        Toast.makeText(MainActivity.this, "Contact Us", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.privacy_policy:
                        Toast.makeText(MainActivity.this, "Privacy Policy", Toast.LENGTH_SHORT).show();
                        break;
                }

                return false;
            }
        });
    }

    private void SetUpToolbar(){
        drawerLayout = findViewById(R.id.drawer_layout);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.app_name, R.string.app_name);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
    }

    @Override
    public void onItemClick(int position) {
        Intent intent = new Intent(MainActivity.this, DetailActivity.class);
        PostClass clickedItem = mExampleList.get(position);
        intent.putExtra(EXTRA_URL, clickedItem.getmUrlToImage());
        intent.putExtra(EXTRA_TITLE, clickedItem.getmTitle());
        intent.putExtra(EXTRA_PUBLISHED_AT, clickedItem.getmPublishedAt());
        intent.putExtra(EXTRA_CONTENT, clickedItem.getmContent());
        startActivity(intent);
    }
}