package com.example.newsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Toolbar;

import java.util.Objects;

public class CategoriesClass extends AppCompatActivity {

    private Toolbar toolbarCategory;
    private CardView cardViewBusiness;
    private CardView cardViewEntertainment;
    private CardView cardViewGeneral;
    private CardView cardViewHealth;
    private CardView cardViewScience;
    private CardView cardViewSports;
    private CardView cardViewTechnology;

    public static final String EXTRA_BUSINESS = "businessClicked";
    public static final String EXTRA_ENTERTAINMENT = "entertainmentClicked";
    public static final String EXTRA_GENERAL = "generalClicked";
    public static final String EXTRA_HEALTH = "healthClicked";
    public static final String EXTRA_SCIENCE = "scienceClicked";
    public static final String EXTRA_SPORTS = "sportsClicked";
    public static final String EXTRA_TECHNOLOGY = "technologyClicked";

    boolean categorySelected = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categories_class);

        Initialization();

        toolbarCategory.setTitle("Select Category");
        toolbarCategory.setTitleTextColor(Color.WHITE);
        setActionBar(toolbarCategory);



        cardViewBusiness.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CategoriesClass.this, MainActivity.class);
                intent.putExtra(EXTRA_BUSINESS, categorySelected);
                startActivity(intent);
                finish();
            }
        });



        cardViewEntertainment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CategoriesClass.this, MainActivity.class);
                intent.putExtra(EXTRA_ENTERTAINMENT, categorySelected);
                startActivity(intent);
                finish();
            }
        });



        cardViewGeneral.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CategoriesClass.this, MainActivity.class);
                intent.putExtra(EXTRA_GENERAL, categorySelected);
                startActivity(intent);
                finish();
            }
        });



        cardViewHealth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CategoriesClass.this, MainActivity.class);
                intent.putExtra(EXTRA_HEALTH, categorySelected);
                startActivity(intent);
                finish();
            }
        });



        cardViewScience.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CategoriesClass.this, MainActivity.class);
                intent.putExtra(EXTRA_SCIENCE, categorySelected);;
                startActivity(intent);
                finish();
            }
        });



        cardViewSports.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CategoriesClass.this, MainActivity.class);
                intent.putExtra(EXTRA_SPORTS, categorySelected);
                startActivity(intent);
                finish();
            }
        });



        cardViewTechnology.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CategoriesClass.this, MainActivity.class);
                intent.putExtra(EXTRA_TECHNOLOGY, categorySelected);
                startActivity(intent);
                finish();
            }
        });
    }

    private void Initialization() {
        toolbarCategory = findViewById(R.id.category_toolbar);
        cardViewBusiness = findViewById(R.id.business_card);
        cardViewEntertainment = findViewById(R.id.entertainment_card);
        cardViewGeneral = findViewById(R.id.general_card);
        cardViewHealth = findViewById(R.id.health_card);
        cardViewScience = findViewById(R.id.science_card);
        cardViewSports = findViewById(R.id.sports_card);
        cardViewTechnology = findViewById(R.id.technology_card);
    }
}