package com.MYQ.myquiz;

import androidx.annotation.NonNull;

public class Exam {
    public static final int SSC_CGL_1 = 1;
    public static final int SSC_CGL_2 = 2;
    public static final int SSC_CGL_3 = 3;
    public static final int SSC_CGL_4 = 4;

    private int id;
    private String name;

    public Exam(){

    }

    public Exam(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @NonNull
    @Override
    public String toString() {
        return getName();
    }
}
