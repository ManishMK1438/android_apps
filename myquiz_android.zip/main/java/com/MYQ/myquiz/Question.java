package com.MYQ.myquiz;

import android.os.Parcel;
import android.os.Parcelable;

public class Question implements Parcelable {
    public static final String SUBJECT_ENGLISH = "English";
    public static final String SUBJECT_GENERAL_AWARENESS = "GeneralAwareness";

    public static final String YEAR_2020 = "2020";
    public static final String YEAR_2019 = "2019";


    private int id;
    private String question;
    private String option1;
    private String option2;
    private String option3;
    private String option4;
    private int answerNr;
    private String subject;
    private String year;
    private int examId;




    public Question(){

    }


    public Question(String question, String option1, String option2, String option3, String option4, int answerNr, String subject, int examId, String year ) {
        this.question = question;
        this.option1 = option1;
        this.option2 = option2;
        this.option3 = option3;
        this.option4 = option4;
        this.answerNr = answerNr;
        this.subject = subject;
        this.year = year;
        this.examId = examId;



    }

    protected Question(Parcel in) {
        id = in.readInt();
        question = in.readString();
        option1 = in.readString();
        option2 = in.readString();
        option3 = in.readString();
        option4 = in.readString();
        answerNr = in.readInt();
        subject = in.readString();
        year = in.readString();
        examId = in.readInt();


    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(question);
        dest.writeString(option1);
        dest.writeString(option2);
        dest.writeString(option3);
        dest.writeString(option4);
        dest.writeInt(answerNr);
        dest.writeString(subject);
        dest.writeString(year);
        dest.writeInt(examId);


    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Question> CREATOR = new Creator<Question>() {
        @Override
        public Question createFromParcel(Parcel in) {
            return new Question(in);
        }

        @Override
        public Question[] newArray(int size) {
            return new Question[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getOption1() {
        return option1;
    }

    public void setOption1(String option1) {
        this.option1 = option1;
    }

    public String getOption2() {
        return option2;
    }

    public void setOption2(String option2) {
        this.option2 = option2;
    }

    public String getOption3() {
        return option3;
    }

    public void setOption3(String option3) {
        this.option3 = option3;
    }

    public String getOption4() {
        return option4;
    }

    public void setOption4(String option4) {
        this.option4 = option4;
    }

    public int getAnswerNr() {
        return answerNr;
    }

    public void setAnswerNr(int answerNr) {
        this.answerNr = answerNr;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public int getExamId() {
        return examId;
    }

    public void setExamId(int examId) {
        this.examId = examId;
    }



    public static String[] getAllSubjects(){
        return new String[]{
                SUBJECT_ENGLISH, SUBJECT_GENERAL_AWARENESS
        };
    }

    public static String[] getAllYears(){
        return new String[]{
                YEAR_2020, YEAR_2019
        };
    }
}
