package com.MYQ.myquiz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.media.MediaPlayer;

import androidx.annotation.Nullable;

import com.MYQ.myquiz.QuizContract.*;

import java.util.ArrayList;
import java.util.List;

public class QuizDbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "MYQuiz.db";
    private static final int DATABASE_VERSION = 1;

    private static QuizDbHelper instance;

    private SQLiteDatabase db;

    private QuizDbHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static synchronized QuizDbHelper getInstance(Context context){
        if (instance == null){
            instance = new QuizDbHelper(context.getApplicationContext());
        }
        return instance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        this.db = db;



        final String SQL_CREATE_EXAM_TABLE = "CREATE TABLE " + ExamTable.TABLE_NAME +
                " ( " + ExamTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ExamTable.COLUMN_NAME + " TEXT " + " ) ";

        final String SQL_CREATE_QUESTIONS_TABLE = "CREATE TABLE " + QuestionsTable.TABLE_NAME +
                " ( " + QuestionsTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuestionsTable.COLUMN_QUESTION + " TEXT, " + QuestionsTable.COLUMN_OPTION1 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION2 + " TEXT, " + QuestionsTable.COLUMN_OPTION3 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION4 + " TEXT, " + QuestionsTable.COLUMN_ANSWER_NUMBER + " INTEGER, " +
                QuestionsTable.COLUMN_SUBJECT + " TEXT, " + QuestionsTable.COLUMN_YEAR + " TEXT, " +
                QuestionsTable.COLUMN_EXAM_ID + " INTEGER, " +
                "FOREIGN KEY(" + QuestionsTable.COLUMN_EXAM_ID + ") REFERENCES " +
                ExamTable.TABLE_NAME + "(" + ExamTable._ID + ")" + "ON DELETE CASCADE " +
                ")";


        db.execSQL(SQL_CREATE_EXAM_TABLE);
        db.execSQL(SQL_CREATE_QUESTIONS_TABLE);

        fillExamTable();
        fillQuestionstable();

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + ExamTable.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + QuestionsTable.TABLE_NAME);
        onCreate(db);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }




    private void fillExamTable(){
        Exam e1 = new Exam("SSC CGL-1");
        addExam(e1);

        Exam e2 = new Exam("SSC CGL-2");
        addExam(e2);

        Exam e3 = new Exam("SSC CGL-3");
        addExam(e3);

        Exam e4 = new Exam("SSC CGL-4");
        addExam(e4);

    }


    private void addExam(Exam exam){
        ContentValues cv = new ContentValues();
        cv.put(ExamTable.COLUMN_NAME, exam.getName());
        db.insert(ExamTable.TABLE_NAME, null, cv);

    }




    private void fillQuestionstable(){

        //ENGLISH QUESTIONS 1

        Question q1 = new Question("Select the most appropriate word to fill in the blank. \n" +
                " I like both tea and coffee but prefer the ______.",
                "later", "least", "last", "latter", 4, Question.SUBJECT_ENGLISH ,Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q1);

        Question q2 = new Question(" Select the correct passive form of the given sentence. \n " +
                "They offered me a chair", "A chair is offered to me by them.",
                "I was offered a chair by them.", "I offered a chair to them.", "A chair was being offered to me", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q2);

        Question q3 = new Question("Select the most appropriate meaning of the given idiom. \n " +
                "A bed of roses ",
                "A pleasant perfume", "An easy and happy situation ", "A difficult path", "A valley full of flowers", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q3);

        Question q4 = new Question("Select the most appropriate meaning of the given idiom. \n " +
                "A close-fisted person\n",
                "A strong person", "A kind person", "A miserly person", "A cruel person", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q4);

        Question q5 = new Question("Select the correct indirect form of the given sentence. \n" + "What a good idea!" + "Seema remarked.",
                "Seema exclaimed that it was a very good idea.", "Seema told what an idea!", "Seema exclaimed that the idea is good.", "Seema said what a good idea it is", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q5);

        Question q6 = new Question("Select the wrongly spelt word.\n",
                "Choir", "Champion", "Charisma", "Chouffer", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q6);

        Question q7 = new Question(" Given below are four jumbled sentences. Out of the given options pick the one that gives their correct order.\n"+
                "A. Aesop was one of them who lived in Greece about 2500 years ago \n" + "B. He told many interesting stories to the people.\n" +
                "C. here were many talented people in ancient Greece.\n" + "D. Although he was ugly, he had a very clever brain.\n",
                "BADC", "BDAC", "CADB", "CDBA", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q7);

        Question q8 = new Question("Select the most appropriate word to correct the given sentence. If no substitution is required, select ‘No improvement’.\n" +
                "The diver dive in the pool from a great height.\n",
                "dived at the pool", "No improvement ", "dived into the pool", "dives to a pool", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q8);

        Question q9 = new Question("Given below are four jumbled sentences. Out of the given options pick the one that gives their correct order.\n"+
                "A.  He is a gifted volleyball player. \n" + "B.  But now a days he does not play international matches.\n" +
                "C. It is because he had an accident last year. \n" + "D. Sanjay is my best friend.\n",
                " ABCD", "DCAB", "CDBA", " DABC", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q9);

        Question q10 = new Question(" Select synonym of the given word.\n" + "RETAIN\n",
                "Convey", "Destroy", "Maintain", "Gain", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q10);

        Question q11 = new Question("Select synonym of the given word.\n" + "EXPENSIVE",
                "Dear", "Mild", "Sober", "Gentle", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q11);

        Question q12 = new Question("Select the most appropriate word to fill in the blank.\n" + "He tried to ______ my ring.",
                "stile", "still", "steel", "steal", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q12);

        Question q13 = new Question("Select the wrongly spelt word.\n",
                "Cremator", "Cracker", "Cricketer", "Creater", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q13);

        Question q14 = new Question("Select the most appropriate word to correct the given sentence. If no substitution is required, select ‘No improvement’.\n" +
                "Hardly had he sit on the chair than it broke.\n",
                "sat on the chair when", "No improvement ", "sat onto a chair then ", "sit in the chair when", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q14);

        Question q15 = new Question("In the sentence identify the segment which contains the grammatical error.\n" +
                "My brother, who live in Delhi, has written me a letter.",
                "me a letter ", "has written", "who live in Delhi ", "My brother", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q15);

        Question q16 = new Question("Select antonym of the given word.\n" + "DEXTERITY",
                "Ignorance", "Skill ", "Mastery ", "Agility", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q16);

        Question q17 = new Question("Select the word which means the same as the group of words given.\n" + "Incapable of paying debts\n",
                "Obsolete ", "Insolvent ", "Corrupt ", "Extravagant", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q17);

        Question q18 = new Question("Select one word for the following group of words.\n" + "One who loves his country",
                "Conspirator ", "Collaborator ", "Patriot ", "Traitor", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q18);

        Question q19 = new Question("Select antonym of the given word.\n" + "DIVIDE",
                "Split ", "Unite ", "Break ", "Engulf", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q19);

        Question q20 = new Question(" Select the most appropriate ANTONYM of the given word.\n" + "Persist",
                "Continue ", "Insist ", "Cease ", "Remain ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q20);








        // GENERAL AWARENESS QUESTIONS 1

        Question q21 = new Question("The police of which state was honoured with the President's Colours award in December 2019?\n",
                "Tamil Nadu ", "Maharashtra ", "Gujarat ", "Kerala", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q21);

        Question q22 = new Question("VISHWAS, which is a major e-governance initiative launched by the government in January 2020, is the acronym for which of the following?\n",
                "Video Integration and State Wide Advanced System ", "Video Interface and State Wide Advanced Security", "Video Integration and State Wide Advanced Security ", "Video Integration and System Wide Advanced Security", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q22);

        Question q23 = new Question("In January 2020, B. Sai Deepak set a Guinness World Record for most side lunges in 60 seconds. How many lunges did he do?\n",
                "50", "59", "40 ", "30", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q23);

        Question q24 = new Question("The 23rd National Youth Festival (NYF) 2020 was celebrated in Lucknow to commemorate the birth anniversary of ______.\n",
                "Mahatma Gandhi", "Swami Vivekananda ", "Jawaharlal Nehru", "Sardar Vallabhbhai Patel", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q24);

        Question q25 = new Question("Which dynasty built the pancha rathas of Mahabalipuram?\n",
                "Chera", "Chola ", "Pallava ", "Satavahana", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q25);

        Question q26 = new Question("The famous 11-day long ‘Dhanu Jatra’, considered as the largest open-air theatre of the world is celebrated in which state?\n",
                "Manipur ", "Meghalaya ", "Odisha ", "Assam", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q26);

        Question q27 = new Question("What was the theme of the 107th Indian Science Congress held in Bengaluru?\n",
                "Reaching the Unreached through Science and Technology", "Science and Technology: Rural Development", "Science and Technology for National Development", "Future India : Science and Technology", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q27);

        Question q28 = new Question("Jasprit Bumrah has been selected to receive which of the following awards for his performance in international cricket in the 2018-19 season?\n",
                "M.A. Chidambaram", "Madhavrao Scindia ", "Polly Umrigar", "C.K. Nayudu", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q28);

        Question q29 = new Question("Chiropody is a branch of science related to which part of the body?\n",
                "Feet ", "Lungs ", "Liver ", "Kidney", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q29);

        Question q30 = new Question("Ishwar Sharma has been honoured with the Global Child Prodigy Award 2020. What is this award associated with?\n",
                "Science ", "Yoga ", "Sports ", "Literature", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q30);

        Question q31 = new Question("Which National Park among the following is the largest protected area in the Eastern Himalayan sub-region?\n",
                "Jim Corbett National Park ", "Bandipur National Park", "Keibul Lamjao National Park", "Namdapha National Park", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q31);

        Question q32 = new Question("In which year was the Nahargarh Fort in Jaipur built by Maharaja Sawai Jai Singh II ?\n",
                "1734 ", "1800 ", "1780 ", "1805", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q32);

        Question q33 = new Question("What is the colour of the light emitted by the Sun?\n",
                "Red ", "Yellow ", "White ", "Orange", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q33);

        Question q34 = new Question("Pongal festival is celebrated for four days in Tamil Nadu. What is the fourth day of Pongal called?",
                "Kaanum Pongal ", "Thai Pongal ", "Bhogi Pongal", "Mattu Pongal", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q34);

        Question q35 = new Question(" In which year was the Currency Building in the BBD Bagh or Dalhousie area of Kolkata constructed?\n",
                "1900 ", "1910 ", "1850 ", "1833", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q35);

        Question q36 = new Question("Which of the following rivers flows through Tiruttani a famous pilgrimage place of South India?\n",
                "Vaigai ", "Palar ", "Kaveri ", "Nandi", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q36);

        Question q37 = new Question("Which is the first Indian company to hit the 10 lakh crore mark in market capitalisation?\n",
                "Tata Consultancy Services", "HDFC Bank", "ICICI Bank", "Reliance Industries", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q37);

        Question q38 = new Question("As per the government rules, how much percentage of advance tax needs to be paid by 15th June by an individual who is liable to pay advance tax?\n",
                "15%", "10% ", "25% ", "30% ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q38);

        Question q39 = new Question("G. Babita Rayudu took charge as an Executive Director for which of the following organisations in January 2020?\n",
                "The Securities and Exchange Board of India ", "Bombay Stock Exchange", "Small Industries Development Bank of India", "Insurance Regulatory and Development Authority of India\n", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q39);

        Question q40 = new Question("The Indian Railways has integrated its helpline numbers into a single number. What is the number?\n",
                "160 ", "145 ", "139 ", "150", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q40);

        Question q41 = new Question("In which of the following locations was the Quit India Movement launched by Mahatma Gandhi in 1942?\n",
                "Pragati Maidan", "Jallianwala Bagh ", "August Kranti Maidan", "Shivaji Park", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q41);

        Question q42 = new Question("Which district has been awarded the Plastic Waste Management Award -2020 for being the best district of India in the plastic waste management category during Swachhta Hi Seva 2019?\n",
                "Dibrugarh ", "Majuli ", "Jorhat ", "Hojai", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q42);

        Question q43 = new Question("In terms of area, which state has the largest forest cover in India?\n",
                "Odisha ", "Madhya Pradesh ", "Maharashtra ", "Kerala", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q43);

        Question q44 = new Question("The researchers of which academic institution employed the nanoscale phenomenon called 'Electrokinetic streaming potential' to harvest energy from flowing water on a small scale like water flowing through household water taps?\n",
                "IIT Guwahati ", "IIT Bombay ", "IIT Delhi", "IIT Madras", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q44);

        Question q45 = new Question("Name the law in Physics which states that equal volume of all gases under the same conditions of temperature and pressure contain equal number of molecules.\n",
                "Charles's Law ", "Ohm’s Law", "Avogadro’s Law ", "Boyles's Law", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2020);
        addQuestion(q45);







        //GENERAL AWARENESS QUESTIONS 2

        Question q46 = new Question(" Alyssa Healy who created a world record by becoming the highest scorer in women's T20I, belongs to ______.\n",
                "Australia  ", "Canada  ", "India  ", "Japan ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q46);

        Question q47 = new Question(" The SDG India index is developed by ______. \n",
                "World Bank ", "NITI Aayog  ", "Ministry of Home Affairs  ", "Ministry of Environmental, Forests and Climate Change ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q47);

        Question q48 = new Question(" Which of the following gases is consistently seen to be most abundant in a volcanic eruption?\n",
                "Carbon Dioxide  ", "Hydrogen Sulphide  ", "Water vapour  ", "Sulphur Dioxide ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q48);

        Question q49 = new Question(" The Supreme Court has declared access to the internet a fundamental right under Article ______ of the Indian Constitution. \n",
                "14  ", "21  ", "19  ", "17 ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q49);

        Question q50 = new Question(" Which of the following diseases is NOT transmitted from one person to another? \n",
                "Hepatitis B  ", "Syphilis  ", "Cirrhosis  ", "AIDS ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q50);

        Question q51 = new Question(" Who is the first General of the Indian Army, whose retirement day is celebrated as the 'Armed Forces Veterans Day' every year?\n",
                " General K.S. Thimayya  ", "General Maharaj Rajendra Sinhji  ", "General K. M. Cariappa ", "General S.M. Srinagesh ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q51);

        Question q52 = new Question(" Which leader gave us the C R Formula?  \n",
                "Mahatma Gandhi  ", "C. R. Das  ", "Tilak ", "C. Rajagopalachari ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q52);

        Question q53 = new Question(" UN Women propose to partner with ______ gender park with an aim to secure gender parity in South Asia.\n",
                "Kerala’s ", "Rajasthan’s  ", "Punjab’s  ", "Haryana’s ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q53);

        Question q54 = new Question(" If the inflation in an economy is rising steadily, the Central Bank might ______.\n",
                "increase the repo rate  ", "decrease the reverse repo rate ", "decrease the repo rate  ", "keep the repo rate unchanged ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q54);

        Question q55 = new Question(" Which International organisation released the ‘World Energy Outlook 2019’ Report? \n",
                "World Trade Organisation ", "UNESCO  ", "United Nations  ", "International Energy Agency ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q55);

        Question q56 = new Question(" Which Indian journalist was honoured with India's Most Powerful Woman in Media Award during the prestigious Confluence Excellence Award ceremony held in the British parliament on 27 September 2019? \n",
                "Kalli Puri  ", "Sunetra Chaudhary ", "Sona Choudhary  ", "Anubha Bhonsle ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q56);

        Question q57 = new Question(" Merchant discount rate refers to ______.\n",
                "the rate charged to a merchant for payment processing services on debit and credit card transactions  ",
                "the total discount a merchant offers on online transactions  ",
                "only taxes that a digital payment entails  ",
                "the total discount a bank offers to the merchant for promoting online transactions ",
                1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q57);

        Question q58 = new Question(" When did the Vikrama Era begin?\n",
                "47 BC  ", "55 BC  ", "50 BC  ", "57 BC ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q58);

        Question q59 = new Question(" Name the only metal that is antibacterial.\n",
                "Iron  ", "Copper  ", "Aluminium  ", "Sodium ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q59);

        Question q60 = new Question(" Mehrunnisa who was known as Nur Jahan was the wife of ______.\n",
                "Jahangir  ", "Shah Jahan  ", "Akbar  ", "Aurangzeb ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q60);

        Question q61 = new Question(" Which of the following is the primary sex organ in females?\n",
                "Uterus  ", "Ovary  ", "Vagina  ", "Fallopian tube  ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q61);

        Question q62 = new Question("Who performs the task of capturing oxygen in the blood? \n",
                "Chlorophyll  ", "Haemoglobin  ", "Red blood cells  ", "White blood cells  ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q62);

        Question q63 = new Question("In the sequence of planets in the Solar system, which planet comes in between Mercury and Earth? \n",
                "Mars  ", "Uranus  ", "Venus  ", "Jupiter  ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q63);

        Question q64 = new Question("Which of the following is a natural flame retardant? \n",
                "DNA  ", "Flowers  ", "RNA  ", "Skin  ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q64);

        Question q65 = new Question("Which of the following is the first South Asian country to call match-fixing a crime? \n",
                "Sri Lanka  ", "India  ", "Pakistan  ", "Nepal  ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q65);

        Question q66 = new Question("In which year did D.C. Sircar publish Indian Epigraphy and Indian Epigraphical Glossary? \n",
                "1964-65  ", "1966-67  ", "1965-66  ", "1967-68  ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q66);

        Question q67 = new Question("On which river and in which state is the Jayakwadi dam situated?  \n",
                "Godavari river - Maharashtra  ", "Ravi river - Punjab  ", "Periyar river - Kerala  ", "Banas river - Rajasthan  ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q67);

        Question q68 = new Question("Madhavpur Mela takes place in ______.  \n",
                "Maharashtra  ", "Gujarat  ", "Uttar Pradesh  ", "Madhya Pradesh  ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q68);

        Question q69 = new Question("Name the Indian wrestler who has been named the Junior Freestyle Wrestler of the year (2019) by United World Wrestling (UWW). \n",
                "Deepak Punia  ", "Kamareddy  ", "B.P. Raju  ", "Amita Bagchi  ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q69);

        Question q70 = new Question("To which of the following Indian states does Mardani Khel, one of the famous martial art forms in India belong? \n",
                "Rajasthan  ", "Madhya Pradesh  ", "Maharashtra  ", "Uttar Pradesh  ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q70);







        //ENGLISH QUESTIONS 2

        Question q71 = new Question("Select the correct passive form of the given sentence.\n" + "The farmer is ploughing the fields. \n",
                "The fields are being ploughed by the farmer. ",
                "The fields are ploughed by the farmer. ",
                "The fields have been ploughed by the farmer. ",
                "The fields were ploughed by the farmer. ",
                1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q71);

        Question q72 = new Question("Identify the segment in the sentence which contains the grammatical error. If there is no error, select 'No error'\n" + "Those who are late they will not be allowed inside the classroom. \n",
                "Those who are late ",
                "No error  ",
                "inside the classroom ",
                "they will not be allowed  ",
                4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q72);

        Question q73 = new Question("Select the most appropriate option to correct the given sentence. If there is no need to correct it, select No improvement.\n" + "We came back because we had ran out of money. \n",
                "we had run  ",
                "No improvement  ",
                "we run  ",
                "we have ran  ",
                1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q73);

        Question q74 = new Question("Select the option that can be used as a one-word substitute for the given group of words/phrase.\n" + "Having two opposing feelings at the same time \n",
                "Ambivalent  ",
                "Equivalent  ",
                "Coinciding  ",
                "Contemporary  ",
                1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q74);

        Question q75 = new Question("Select the correct indirect form of the given sentence.\n" + "What a rare flower!" + " she said." ,
                "She asked if it was a rare flower.  ",
                "She told that what a rare flower it was.  ",
                "She exclaimed what a rare flower it is.  ",
                "She exclaimed that it was a very rare flower.  ",
                4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q75);

        Question q76 = new Question("Identify the segment in the sentence which contains the grammatical error. If there is no error, select 'No error'\n" + "Everyone except she have travelled by air. \n",
                "Everyone except  ", "travelled by air  ", "No error  ", "she have  ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q76);

        Question q77 = new Question("Select the most appropriate synonym of the given word.\n" + "Ovation \n",
                "Censure  ", "Applause  ", "Preparation  ", "Creation ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q77);

        Question q78 = new Question("Select the option that can be used as a one-word substitute for the given group of words/phrase.\n" + "A group of ships  \n",
                "squad  ", "swarm  ", "colony  ", "fleet  ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q78);

        Question q79 = new Question("Select the most appropriate synonym of the given word.\n" + "Preferred \n",
                "Feared  ", "Compared  ", "Adored  ", "Favoured  ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q79);

        Question q80 = new Question("Select the most appropriate meaning of the given idiom.\n" + "Chicken-hearted  \n",
                "Selfish  ", "Cowardly  ", "Generous  ", "Miserly  ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q80);

        Question q81 = new Question("Select the most appropriate option to correct the given sentence. If there is no need for correction, select No improvement.\n" + "When it started raining, I ran to the nearer house for shelter. \n",
                "a near house  ", "No improvement ", "the near house  ", "the nearest house  ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q81);

        Question q82 = new Question("Given below are four jumbled sentences. Out of the given options pick the one that gives their correct order. \n"
                + "A. Much of this war had taken place along the Western Front.\n" + "B. Both sides had dug in deep and each lost many men over little ground.\n"
                + "C. This front was a line of trenches across which the two sides faced each other.\n" + "D. Andre Maginot had fought a war with the French against the Germans.\n",
                "BCDA    ", "ACDB  ", "DACB  ", "DBCA  ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q82);

        Question q83 = new Question("Select the wrongly spelt word. \n",
                "Grief  ", "Sieze  ", "Fierce  ", "Piece  ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q83);

        Question q84 = new Question("Select the most appropriate meaning of the given idiom.\n" + "By and by \n",
                "On the whole ", "By any means ", "Suddenly  ", "Gradually  ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q84);

        Question q85 = new Question("Select the most appropriate ANTONYM of the given word.\n" + "Glee  \n",
                "Woe  ", "Fun  ", "Joy  ", "Bliss  ", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q85);

        Question q86 = new Question("Select the INCORRECTLY spelt word.",
                "Alliance   ", "Acquaintence   ", "Acquisition   ", "Abandon   ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q86);

        Question q87 = new Question("Select the most appropriate option to fill in the blank.\n" + "The roof of the old building ______ during the storm.",
                "scratched   ", "demolished   ", "destroyed   ", "collapsed   ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q87);

        Question q88 = new Question("Select the most appropriate option to fill in the blank.\n" + "She ______ how the magician had performed the rope trick.",
                "suspected   ", "bewildered   ", "wondered   ", "puzzled   ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2020);
        addQuestion(q88);








        //ENGLISH QUESTIONS 3

        Question q89 = new Question("Select the correct passive form of the given sentence.\n" + "A child could understand his theory.",
                "His theory can be understood by a child.",
                "His theory could be understood by a child.",
                "His theory was understood by a child.",
                "His theory is being understood by a child.",
                2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q89);

        Question q90 = new Question("Select the most appropriate option to fill in the blank.\n" + "The poor man was ______ entry to the restaurant.",
                "denied ", "derived ", "deluded ", "devoid ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q90);

        Question q91 = new Question("In the sentence identify the segment which contains the grammatical error.\n" + "We had a long discussion at a cup of coffee.",
                "We had ", "of coffee ", "a long discussion ", "at a cup ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q91);

        Question q92 = new Question("Given below are four jumbled sentences. Out of the given options pick the one that gives their correct order.\n" +
                "A. These lotteries organised by State Governments sell dreams.\n" +
                "B. Lured by this, millions of poor people waste their hard-earned money.\n" +
                "C. Crores of rupees and gold are offered as prizes. \n" +
                "D. People buy lotteries hoping to become rich overnight.\n",
                "DACB ",
                "CABD ",
                "CBAD ",
                "DBCA ",
                1 , Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q92);

        Question q93 = new Question("Select the most appropriate antonym of the given word.\n" + "FICKLE",
                "Subtle ", "Crafty ", "Stable ", "Flighty ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q93);

        Question q94 = new Question("Select the most appropriate meaning of the given idiom.\n" + "Pull a fast one",
                "Trick someone ", "Believe someone easily ", "Progress fast ", "Take quick action ",1 , Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q94);

        Question q95 = new Question("Select the INCORRECTLY spelt word.",
                "Obsolete ", "Opportunity ", "Omision ", "Obscure ",3 , Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q95);

        Question q96 = new Question("Select the most appropriate one word substitution for the given group of words.\n" + "Pertaining to an individual from birth ",
                "Congenital ", "Anomaly ", "Habitual ", "Chronic ",1 , Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q96);

        Question q97 = new Question("Select the most appropriate synonym of the given word.\n" + "DISHEARTENED",
                "disgusted ", "disliked", "disgraced ", "depressed ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q97);

        Question q98 = new Question("Select the correct indirect form of the given sentence.\n" + "Mahesh said to Rita, \"Don't play in the sun.\"",
                "Mahesh told to Rita to not play in the sun.",
                "Mahesh ordered Rita that not play in the sun.",
                "Mahesh requested Rita that don't play in the sun.",
                "Mahesh advised Rita not to play in the sun.",
                4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q98);

        Question q99 = new Question("Select the most appropriate meaning of the given idiom.\n" + "See eye to eye ",
                "See clearly ", "Stare at someone ", "Agree with someone ", "Be suspicious ",3 , Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q99);

        Question q100 = new Question("Select the INCORRECTLY spelt word.",
                "Rebel ", "Edible ", "Monarch ", "Delegait ",4 , Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q100);

        Question q101 = new Question("In the sentence identify the segment which contains the grammatical error.\n" + "The both children go to the same school.",
                "The both ", "same school ", "children go ", "to the ",1 , Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q101);

        Question q102 = new Question("Select the most appropriate one word substitution for the given group of words.\n" + "To increase the speed ",
                "Accelerate ", "Exhilarate ", "Activate ", "Assimilate ",1 , Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q102);

        Question q103 = new Question("Given below are four jumbled sentences. Out of the given options pick the one that gives their correct order.\n" +
                "A. These are generated by a violent undersea disturbance or ocean activity.\n" +
                "B. Once generated, they travel outward on the ocean surface in all directions.\n" +
                "C. A tsunami is made up of a series of very long waves.\n" +
                "D. Spreading thus, they look like ripples caused by throwing a rock in a pond.",
                "BDCA ", "CBDA ", "BADC ", "CABD ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q103);

        Question q104 = new Question("Select the most appropriate synonym of the given word.\n" + "CORDIAL ",
                "warm ", "rude ", "hard ", "cold ", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q104);

        Question q105 = new Question("Select the most appropriate option to fill in the blank.\n" + "Have you ______ for a job in this company?",
                "approved ", "appointed ", "applied ", "supplied ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q105);

        Question q106 = new Question("Select the most appropriate antonym of the given word.\n" + "HASTE ",
                "Dash ", "Rush ", "Lose ", "Delay ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q106);

        Question q107 = new Question("Select the most appropriate option to correct the given sentence. If there is no need to correct it, select No improvement.\n" + "If they will get married , they will probably settle in Mumbai.",
                "If they will be getting married ", "If they get married ", "No improvement ", "If they had got married ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q107);

        Question q108 = new Question("Select the most appropriate option to correct the given sentence. If there is no need to correct it, select No improvement.\n"+ "They stopped to laugh as soon as the teacher entered the classroom.",
                "No improvement ", "stop laughing ", "stopped laugh ", "stopped laughing ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q108);










        //GENERAL AWARENESS QUESTIONS 3

        Question q109 = new Question("Ozone at the higher level of the atmosphere is a product of ______ acting on oxygen molecules.",
                "IR radiation  ", "UV radiation  ", "gamma rays  ", "x-rays  ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q109);

        Question q110 = new Question("Which ISO certification pertains to Environmental Management Systems?",
                "27001  ", "22000  ", "9001  ", "14001  ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q110);

        Question q111 = new Question("Which country hosted the 13th South Asian Games?",
                "Bhutan  ", "India  ", "Bangladesh ", "Nepal  ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q111);

        Question q112 = new Question("In January 2020, with which country did India sign a MoU for content exchange programme between All India Radio and Betar?",
                "Sri Lanka  ", "Nepal  ", "Bhutan  ", "Bangladesh  ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q112);

        Question q113 = new Question("Who is the author of the book 'Hazaar Chaurasi Ki Maa'?",
                "Sugathakumari  ", "Krishna Sobti  ", "Mahasweta Devi  ", "Rita Kothari  ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q113);

        Question q114 = new Question("Which of the following states does NOT share its boundary with Bhutan?",
                "Sikkim  ", "Arunachal Pradesh  ", "Meghalaya  ", "West Bengal  ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q114);

        Question q115 = new Question("Which female Indian cricketer won the BCCI C.K. Nayudu Lifetime Achievement Award for 2019?",
                "Shantha Rangaswamy ", "Jhulan Goswami ", "Anjum Chopra  ", "Diana Edulji  ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q115);

        Question q116 = new Question("Which among the following is the food tube?",
                "Oesophagus  ", "Thymus  ", "Larynx  ", "Aorta  ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q116);

        Question q117 = new Question("The Battle of Chausa was fought between Humayun and ______.",
                "Nadir Shah  ", "Sher Shah Suri  ", "Hemu  ", "Krishnadeva Raya  ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q117);

        Question q118 = new Question("In July 2019, which among the following operations was launched by the BSF to fortify the Pakistan border in Punjab and Jammu?",
                "Sudarshan  ", "Garuda  ", "Vayuputra  ", "Chakravyuh  ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q118);

        Question q119 = new Question("The SASTRA - Ramanujan Prize is awarded in the field of:",
                "Dance  ", "Mathematics  ", "Literature  ", "Chemistry  ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q119);

        Question q120 = new Question("Which of the following is an east flowing river?",
                "Brahmani  ", "Sharavati ", "Mahi  ", "Sabarmati  ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q120);

        Question q121 = new Question("The Act that transferred the power from the British East India Company to the British Crown in India was:",
                "Government of India Act, 1833  ", "Government of India Act, 1947 ", "Government of India Act, 1858  ", "Government of India Act, 1835  ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q121);

        Question q122 = new Question("In the context of rivers and their tributaries, which of the following pairs is correct?",
                "Godavari – Kabini ", "Krishna – Manjra ", "Indus – Subansiri  ", "Alaknanda – Pindar ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q122);

        Question q123 = new Question("Which of the following monuments is NOT a part of the Qutub Complex?",
                "Quwwat-ul-Islam Mosque  ", "Buland Darwaza  ", "Qutub Minar  ", "Alai Darwaza  ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q123);

        Question q124 = new Question("Which of the following statements is correct with reference to the Karachi Session of the Congress (1931)?",
                "Mahatma Gandhi presided over the session ",
                "The Khilafat movement was launched at this event ",
                "The Gandhi-Irwin Pact was ratified ",
                "The Quit-India Resolution was passed  ",
                3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q124);

        Question q125 = new Question("With which sport is Archana Kamath associated?",
                "Squash  ", "Table Tennis ", "Badminton  ", "Lawn Tennis  ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q125);

        Question q126 = new Question("How many degrees does the Earth rotate about its own axis in one hour?",
                "15  ", "10  ", "20  ", "24  ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q126);

        Question q127 = new Question("The first electron shell which is the nearest to the nucleus never holds more than 'n' electrons, where 'n' is equal to:",
                "8  ", "6 ", "4  ", "2  ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q127);

        Question q128 = new Question("Under which Article can the Parliament amend the Constitution?",
                "Article 74 ", "Article 374  ", "Article 368 ", "Article 269  ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q128);

        Question q129 = new Question("Which of the following pairs is associated with the taxation system of the Marathas?",
                "Iqta and Jagir ", "Chauth and Sardeshmukhi  ", "Zat and Sawar ", "Polaj and Parauti  ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q129);

        Question q130 = new Question("Under which of the following Amendments to the Constitution of India is defection to another party after election made illegal?",
                "52nd  ", "86th  ", "92nd  ", "61st  ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q130);

        Question q131 = new Question("In which year was NABARD established?",
                "1981  ", "1982  ", "1978  ", "1979  ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q131);

        Question q132 = new Question("Which of the following is a heritage site of Madhya Pradesh?",
                "Sasaram  ", "Bhimbetka  ", "Hampi  ", "Lepakshi  ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q132);

        Question q133 = new Question("The Arid Forest Research Institute is located in ______.",
                "Jodhpur  ", "Ahmedabad  ", "Dehradun  ", "Jaipur  ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2020);
        addQuestion(q133);








        //ENGLISH QUESTIONS 4

        Question q134 = new Question("Select the passive form of the given sentence.\n" + "The manager keeps the work pending. ",
                " The work was kept pending by the manager.",
                " The work are being kept pending by the manager.   ",
                " The work has been kept pending by the manager.  ",
                " The work has been kept pending by the manager.  ",
                4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q134);

        Question q135 = new Question("Select the correct synonym of the given word.\n" + "Obligatory  ",
                "Aggressive   ", "Mandatory   ", "Useless   ", "Reckless  ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q135);

        Question q136 = new Question("Select the most appropriate option to correct the given sentence. If no correction is required, select No improvement.\n" + "The Director will agree with the proposal if we do not exceed the budget.  ",
                "No Improvement   ", "agree on a proposal   ", "agreed by the proposal  ", "agree to the proposal  ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q136);

        Question q137 = new Question(" In the sentence identify the segment which contains the grammatical error.\n" + "One of the boys from our school have been selected for National Badminton Championship. ",
                "for National Badminton Championship   ",
                "have been selected   ",
                "from our school   ",
                "One of the boys  ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q137);

        Question q138 = new Question("Given below are four jumbled sentences. Select the option that gives their correct order" +
                "A. However, the rate of population increase is another important factor to consider.\n" +
                "B. This change can be expressed in two ways.\n" +
                "C. Growth of population refers to the change in the number of inhabitants of a country.\n" +
                "D. First, in terms of absolute numbers and second, in terms of percentage change.  ",
                "CBDA   ", "BDCA   ", "CADB  ", "BADC  ", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q138);

        Question q139 = new Question(" Fill in the blank with the most appropriate word.\n" + "We must ______ help to the homeless and physically disabled people.  ",
                "exert   ", "contribute   ", "render   ", "donate  ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q139);

        Question q140 = new Question("Select the most appropriate option to correct the given sentence. If no correction is required, select No improvement.\n" +
                "The captain as well the players were responsible for winning the trophy.  ",
                "The captain as well as the players was  ",
                "No Improvement   ",
                "The captain also the players were   ",
                "As The captain with the players were  ", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q140);

        Question q141 = new Question("Select the appropriate meaning of the given idiom.\n" + "A hard nut to crack ",
                " Easily encouraged   ", " Easily disappointed   ", " Not restrained  ", " A difficult problem  ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q141);

        Question q142 = new Question("Select the correct antonym of the given word.\n" + "Exodus  ",
                "Departure   ", "Arrival   ", "Exit   ", "Refund  ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q142);

        Question q143 = new Question("Select the correctly spelt word.  ",
                "exhail   ", "exteract   ", "exhibit   ", "exhoust  ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q143);

        Question q144 = new Question("Select the word, which means the same as the groups of words given.\n" + "A song sung at a burial  ",
                " Sonnet  ", " Ballad  ", " Hymn  ", " Dirge ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q144);

        Question q145 = new Question(" In the sentence identify the segment which contains the grammatical error.\n" +
                "I can swim very fast when I was only five.  ",
                " I can swim  ", " when I was  ", " only five  ", " very fast ", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q145);

        Question q146 = new Question("Select the appropriate meaning of the given idiom.\n" + "To take French leave ",
                "Leave with written permission   ", "Leave without any intimation   ", "Acknowledge the host  ", "Welcome the host  ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q146);

        Question q147 = new Question("Given below are four jumbled sentences. Select the option that gives their correct order\n" +
                "A. However, they ignore the truth that progress and success are proportional to the labor they put in.\n" +
                "B. The general human tendency is to find faults in the policies framed by the government.\n" +
                "C. They blame the government for their slow progress, expecting miracles and magical transformation in their life.\n" +
                "D. So people openly criticize and condemn the policy makers.  ",
                " CDAB  ", " ABCD  ", " DBAC  ", " BDCA ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q147);

        Question q148 = new Question("Select the correctly spelt word.  ",
                "Humilliation   ", "Sarcasm   ", "Retalaite   ", "Bouquette  ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q148);

        Question q149 = new Question("Select the word, which means the same as the given group of words.\n" +
                "Something that cannot be heard  ",
                "infallible   ", "inaudible   ", "irrevocable   ", "audible  ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q149);

        Question q150 = new Question("Select the indirect narration of the given sentence.\n" +
                "He said to the hotel receptionist, “Can you tell me the tariff of rooms? ",
                "He asked the hotel receptionist that if he can tell him the tariff of rooms.   ",
                "He asked the hotel receptionist to tell him the tariff of rooms.  ",
                "He asked the hotel receptionist if he could tell him the tariff of rooms.   ",
                "He enquired the hotel receptionist if he can tell him the tariff of rooms.  ",
                3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q150);

        Question q151 = new Question("Fill in the blank with the most appropriate word.\n" +
                "Handle this glass table with care because it is ______.",
                "frugal   ", "fragile   ", "ductile   ", "volatile  ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q151);

        Question q152 = new Question("Select the correct antonym of the given word.\n" +
                "Quiescent  ",
                "Peaceful   ", "Dejected   ", "Indifferent   ", "Active  ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q152);

        Question q153 = new Question("Select the correct synonym of the given word.\n" +
                "Scintillating ",
                "Flattering   ", "Boring   ", "Glittering   ", "Stinging  ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q153);









        //GENERAL AWARENESS QUESTIONS 4

        Question q154 = new Question("Which of these institutions fixes the Repo Rate and the Reverse Repo Rate in India?  ",
                "Ministry of Finance  ", "State Bank of India   ", "Reserve Bank of India   ", "Comptroller and Auditor General of India  ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q154);

        Question q155 = new Question("Which of the following books is NOT written by Salman Rushdie?  ",
                "Shame   ", "Midnight's Children  ", "An Area of Darkness   ", "The Satanic Verses  ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q155);

        Question q156 = new Question("As of February 2020, who is the President of Sri Lanka? ",
                "Chandrika Kumaratunga   ", "Gotabaya Rajapaksa   ", "D.M. Jayaratne   ", "Maithripala Sirisena  ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q156);

        Question q157 = new Question("Name the author who won the Sahitya Akademi Award 2019 for his book - An Era of Darkness: The British Empire in India.  ",
                "Vikram Seth   ", "Romila Thapar   ", "Shashi Tharoor   ", "Ramchandra Guha  ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q157);

        Question q158 = new Question("Name the physicist who is credited with the discovery of the Neutron. This 1932 discovery led to his winning the Nobel Prize.  ",
                "Enrico Fermi   ", "J.S. Fleming  ", "James Chadwick   ", "Max Plank  ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q158);

        Question q159 = new Question("As on January 2020, Shri Bhupesh Baghel is the Chief Minister of which of the following states? ",
                "Jharkhand   ", "Haryana   ", "Chhattisgarh   ", "Odisha  ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q159);

        Question q160 = new Question("The Araku Valley, a tourist resort, is located near which of these cities of South India?  ",
                "Kochi   ", "Madurai   ", "Mangalore   ", "Visakhapatnam  ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q160);

        Question q161 = new Question("Sir Thomas Roe came as an official ambassador from King James I of England to which Mughal emperor's court?  ",
                "Shah Jahan   ", "Akbar   ", "Aurangzeb   ", "Jahangir  ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q161);

        Question q162 = new Question("Which of these words refers to the scientific study of domestic dogs?  ",
                "Carpology   ", "Cynology   ", "Chrematistics   ", "Craniology  ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q162);

        Question q163 = new Question("The ruins of the ancient city of Hampi - capital of Vijayanagara - is located in which present day Indian state?  ",
                "Bihar   ", "Haryana   ", "Telangana   ", "Karnataka  ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q163);

        Question q164 = new Question("The World Food Program (WFP) is the food assistance branch of the United Nations. Where is it headquartered?  ",
                "Rome   ", "Paris   ", "New York   ", "Brussels  ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q164);

        Question q165 = new Question("What is the more common name for solid carbon dioxide?  ",
                "Potash   ", "Dry Ice   ", "Quick Silver   ", "Epsom  ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q165);

        Question q166 = new Question("Sultan Qaboos bin Said of ________, the Arab world’s longest-serving ruler and with a reputation for quiet diplomacy passed away recently (2020).  ",
                "Oman   ", "Abu Dhabi   ", "Dubai   ", "Kuwait  ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q166);

        Question q167 = new Question("In which year Sanchi was discovered after being abandoned for nearly 600 Years? ",
                " 1814  ", " 1816  ", " 1818  ", " 1820 ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q167);

        Question q168 = new Question("Veteran freedom fighter, social reformer and feminist Savithribai Phule hailed from which of the following states of India?  ",
                " Rajasthan  ", " Maharashtra  ", " Gujarat  ", " Gujarat  ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q168);

        Question q169 = new Question("Prolific Indian painter Maqbool Fida Husain predominantly used which of these animals to depict a lively and free spirit in his paintings?  ",
                " Elephants  ", " Cows  ", " Horses  ", " Tigers ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q169);

        Question q170 = new Question("From India, who inaugurated the Kartarpur Corridor and flagged off the first set of pilgrims to the final resting place of Sikhism founder Guru Nanak Dev?  ",
                " Manmohan Singh  ", " Narendra Modi  ", " Ram Nath Kovind  ", " Amarinder Singh ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q170);

        Question q171 = new Question("Name the media company that purchased the legendary studio of 21st Century Fox.",
                " Viacom  ", " Disney  ", " Sony  ", " Time Warner ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q171);

        Question q172 = new Question("Red worms have a structure named ______ which helps them in grinding their food.",
                "Gizzard   ", "Esophagus   ", "Crop   ", "Intestine  ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q172);

        Question q173 = new Question("For which of the following sports was Dronavalli Harika, conferred with the prestigious Padma Shri award?  ",
                " Cricket  ", " Archery  ", " Chess  ", " Badminton ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q173);

        Question q174 = new Question("Kolathunadu, Valluvanad and Thekkumkoor were ancient small-time kingdoms in which state of India?  ",
                " Gujarat  ", " Karnataka  ", " Bihar  ", " Kerala ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q174);

        Question q175 = new Question("Who is the first and currently the only batsman to score double hundreds in four consecutive test series?  ",
                " Brian Lara  ", " A.B. de Villiers  ", " Rohit Sharma  ", " Virat Kohli ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q175);

        Question q176 = new Question("What is the uniform GST rate that has been fixed up for lottery prizes by the GST Council? ",
                " 18 %  ", " 32 %  ", " 28 %  ", " 10 % ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q176);

        Question q177 = new Question("Who among the following played the leading lady in the film 'Mission Mangal' that tells the dramatic true story of the women behind India's first mission to Mars? ",
                " Vidya Balan  ", " Kareena Kapoor ", " Deepika Padukone   ", " Kajol ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q177);

        Question q178 = new Question("Which of these bones is NOT a part of the human ear?  ",
                "Incus   ", "Femur   ", "Malleus   ", "Stapes  ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2020);
        addQuestion(q178);









        //ENGLISH QUESTIONS 1 - 2019

        Question q179 = new Question("Select the synonym of the given word.\n" +
                "PATHETIC ",
                "Curious", "Insignificant", "Pitiful", "Dull", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q179);

        Question q180 = new Question("In the sentence identify the segment which contains the grammatical error.\n" +
                "The modern man is busy acquiring more and more wealth and designing ways to invest it in more sense pleasures. ",
                "modern man is busy", "designing ways to invest it", "in more sense pleasures", "acquiring more and more wealth ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q180);

        Question q181 = new Question(" Select the antonym of the given word.\n" +
                "HILARIOUS",
                " Happy ", " Sad ", " Blithe ", " Merry ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q181);

        Question q182 = new Question(" Select the most appropriate word to fill in the blank.\n" +
                "It is an ______ day to start your new business.",
                " audacious ", " auspicious ", " ominous ", " occasional ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q182);

        Question q183 = new Question(" Select the correct indirect form of the given sentence.\n" +
                "He said to me, \"What are you doing?\"",
                " He said what I had been doing. ", " He asked me what I was doing. ", " He asked me that what was I doing. ", " He said that what I was doing. ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q183);

        Question q184 = new Question("Select the most appropriate word to correct the given sentence. If no correction is required, select ‘No improvement’.\n" +
                "There is a great degrade in values in modern age.\n ",
                " degradation of values ", " No improvement ", " deliberation for values ", " demonstration from values ", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q184);

        Question q185 = new Question(" Select the wrongly spelt word.\n",
                " Extension ", " Mansion ", " Ostentasion ", " Persuasion ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q185);

        Question q186 = new Question("Select the most appropriate meaning of the given idiom\n" +
                "On shank's mare\n ",
                " On an elephant ", " On a lion ", " On a bicycle ", "  On foot ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q186);

        Question q187 = new Question(" Select the most appropriate meaning of the given idiom\n" +
                "A snake in the grass\n",
                " A secret enemy ", " A well-wisher ", " A good friend ", " Difficult to find ", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q187);

        Question q188 = new Question(" Select the antonym of the given word.\n" +
                "VICIOUS",
                " Virtuous ", " Baneful ", " Sinful ", " Unfortunate ", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q188);

        Question q189 = new Question("Given below are four jumbled sentences. Out of the given options pick the one that gives their correct order.\n" +
                "A. Nevertheless, sound health, economic security and mental satisfaction are desired by all\n" +
                "B. A change that is conducive to happiness may be termed as progress.\n" +
                "C. But different people find happiness in different things.\n" +
                "D. So, If a change contributes to the growth of these factors, it is progress.\n ",
                " DBCA ", " ABCD ", " BDCA ", " BCAD ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q189);

        Question q190 = new Question("Select one word for the following group of words.\n" +
                "One who leaves his own country to settle in another ",
                " Native ", " Emigrant ", " Foreigner ", " Tourist ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q190);

        Question q191 = new Question("Given below are four jumbled sentences. Out of the given options pick the one that gives their correct order.\n" +
                "A. Can I borrow your camera?\n" +
                "B. I will give it back to you next week.\n" +
                "C. I am going to jungle safari tomorrow.\n" +
                "D. My friend told me that jungle is beautiful in these days.\n ",
                " CADB ", " CDAB ", " BACD ", " ADBC ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q191);

        Question q192 = new Question("Select the most appropriate segment to correct the given sentence. If no substitution is required select ‘No improvement’\n" +
                "A man in need pleaded for help.\n ",
                "  requested for helping ", " promised for help ", " No improvement ", " commanded to help ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q192);

        Question q193 = new Question("In the sentence identify the segment which contains the grammatical error.\n" +
                "The Prime Minister, along with the other ministers have left for America.\n ",
                "  the other ministers\n ", " The Prime Minister along with ", "  for America ", " have left ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q193);

        Question q194 = new Question("Select the correct active form of the given sentence.\n" +
                "The thief was being arrested by the police. ",
                " The police was arresting the thief.\n ", " The police arrested the thief. ", " The police has arrested the thief.\n ", " The police had arrested the thief.\n ", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q194);

        Question q195 = new Question("Select the most appropriate word to fill in the blank.\n" +
                "He ______ a heinous crime. ",
                " happened ", " occurred ", " committed ", " made ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q195);

        Question q196 = new Question("Select the wrongly spelt word.\n ",
                " Practicle ", " Flexible ", " Flashy ", " Elegant ", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q196);

        Question q197 = new Question("Select the synonym of the given word.\n" +
                "PENITENCE",
                " Patience ", " Repentance ", " Misery ", " Admiration ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q197);

        Question q198 = new Question("Select one word for the following group of words.\n" +
                "A period of ten years ",
                " Fortnight ", " Millennium ", " Century ", " Decade ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q198);











        //GENERAL AWARENESS 1 - 2019

        Question q199 = new Question("In January 2020, Home Minister Amit Shah released a book ‘Karmayoddha Granth’. This book is based on the life of ________.\n ",
                " Mahatma Gandhi ", " Jawaharlal Nehru ", "  Sardar Vallabhbhai Patel ", " Narendra Modi ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q199);

        Question q200 = new Question("Which of the following glands is present between the lungs?",
                " Hypothalamus ", " Pineal ", " Pituitary ", " Thymus ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q200);

        Question q201 = new Question("In which state was the Global Investors Meet, ASCEND 2020 organised? ",
                " Gujarat ", " Kerala ", " Maharashtra ", " Rajasthan ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q201);

        Question q202 = new Question("Which law of physics states that the force between the two electric charges reduces to a quarter of its former value when the distance between them is doubled?\n ",
                " Hooke's Law ", " Pascal's Law ", " Stefan's Law ", " Coulomb’s Law ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q202);

        Question q203 = new Question(" Ajatashatru, a ruler of the Haryanka Dynasty, was the son of _____.",
                " Anurudha ", " Bimbisara ", " Naga-Dasak ", " Udayin ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q203);

        Question q204 = new Question("Who among the following was honoured with the 50th Dadasaheb Phalke Award? ",
                " Amitabh Bachchan ", " Kamal Haasan ", " Anupam Kher ", " Naseeruddin Shah ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q204);

        Question q205 = new Question("Which of the following is NOT a vertebrate? ",
                " Snail ", " Bird ", " Mammal ", " Fish ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q205);

        Question q206 = new Question("Borra caves are situated on the East Coast of India in which of the following hills? ",
                " Nagari Hills ", " Ananthagiri Hill ", " Horsley Hills ", " Nallamala Hills  ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q206);

        Question q207 = new Question("In which of the following countries was the 95th edition of the prestigious Hastings\n" +
                "International Chess Congress held? ",
                " Australia ", " Belgium", " England ", " France ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q207);

        Question q208 = new Question("'Industry 4.0' is a complex cyber-physical system which synergies production with digital technologies. The Ministry of Railways and the Department of Science and Technology have joined hands in partnership with which institution for taking up a unique project on 'Industry 4.0'?\n",
                " IIT Bombay ", " IIT Delhi  ", " IIT Kanpur  ", " IIT Madras ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q208);

        Question q209 = new Question(" Who among the following was the last ruler of the Nanda dynasty?\n",
                " Panduka ", " Kaivarta ", " Govishanaka ", " Dhanananda ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q209);

        Question q210 = new Question("Who became the first Indian equestrian to qualify for the Tokyo Olympics 2020? ",
                " Fouaad Mirza ", " Amar Sarin ", " Amit Sinsinwar ", "  Sehej Singh Virk ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q210);

        Question q211 = new Question("Which of the following is the major component of vinegar?",
                " Nitric acid ", " Acetic acid ", " Citric acid ", " Lactic acid  ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q211);

        Question q212 = new Question("Archaeologist R Nagaswamy was honoured at the Silver Jubilee International Conference of Art by which country? ",
                " Nepal ", " Bangladesh ", " Bhutan ", " China ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q212);

        Question q213 = new Question("When we cut an onion, the synthase enzyme converts the amino acid sulfoxides of the onion into which acid?",
                " Nitric acid ", " Citric acid ", " Sulphuric acid ", " Sulfenic acid ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q213);

        Question q214 = new Question("In which state has the Khadi and Village Industries Commission (KVIC) opened the first silk processing plant? ",
                " Tamil Nadu ", " Karnataka ", " Gujarat ", " Maharashtra ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q214);

        Question q215 = new Question("In which year was the foundation stone for the Gateway of India laid in Bombay (now Mumbai)?",
                " 1915 ", " 1905 ", " 1913 ", " 1920 ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q215);

        Question q216 = new Question(" In which district of Karnataka is the Brahmagiri Wildlife Sanctuary located?",
                " Hassan ", " Udupi ", " Mandya ", " Kodagu ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q216);

        Question q217 = new Question("Which of the following festivals means 'Merry making of the Gods'? ",
                " Makar Sankranti ", " Diwali ", " Pongal ", "  Lai Haraoba ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q217);

        Question q218 = new Question(" In which of the following states is the Madhavpur Mela celebrated?",
                " Madhya Pradesh ", " Gujarat ", " Uttar Pradesh ", " Bihar ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q218);

        Question q219 = new Question(" Wings India 2020 is scheduled to be held in which of the following airports?",
                "  Warangal Airport ", " Begumpet Airport ", " Rajahmundry Airport ", " Vijayawada Airport ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q219);

        Question q220 = new Question("What was India's position in the Brand Finance Nation ranking of 2019? ",
                " Seventh ", " Sixth ", " Fifth ", " Third ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q220);

        Question q221 = new Question("Which state’s Legislative Assembly adopted a new logo consisting of the national emblem and foxtail orchid (Rhynchostylis Retusa), the state flower, in January 2020? ",
                " Meghalaya ", " Arunachal Pradesh ", " Mizoram ", " Tripura ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q221);

        Question q222 = new Question(" Objects that shine in the night sky are known as:",
                " constellations ", " celestial bodies ", " meteoroids ", " asteroids ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_1, Question.YEAR_2019);
        addQuestion(q222);






        


        //ENGLISH 2 - 2019

        Question q223 = new Question("Select the most appropriate meaning of the given idiom.\n " + "Back to square one",
                " Neglect something ", " Draw a square ", " Move ahead ", " Come to the original point ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q223);

        Question q224 = new Question("Select the most appropriate word to correct the given sentence. If correction is not required select ‘No improvement’.\n" +
                "To fight on the battlefield for the sake of one's country needs a great strongness. ",
                "  a lots of strength ", " great courage ", " No improvement ", " the greatest strongness  ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q224);

        Question q225 = new Question("Select the wrongly spelt word. ",
                " Consumation ", " Chronology ", " Compromise ", " Competence ", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q225);

        Question q226 = new Question("Select the correct active form of the given sentence.\n" +
                "This beautiful story was written by Maya. ",
                " Maya writes this beautiful story.  ", " Maya wrote this beautiful story. ", "  Maya is writing this beautiful story. ", " Maya was writing this beautiful story. ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q226);

        Question q227 = new Question("Select the antonym of the given word.\n" +
                "LIBERTY ",
                " Convenience ", " Independence ", " Deliverance ", " Dependence ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q227);

        Question q228 = new Question("Select the wrongly spelt word.\n ",
                " Tamarind ", " Tresure ", " Turmoil ", " Truthful ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q228);

        Question q229 = new Question("Select the most appropriate word to fill in the blank.\n" +
                "She ______ on paying the bill at the restaurant.\n ",
                " suggested ", " insisted ", " requested ", " offered ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q229);

        Question q230 = new Question("Select the synonym of the given word.\n" +
                "PREVENT ",
                " Avert ", " Allow ", " Construct ", " Provoke ", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q230);

        Question q231 = new Question("Select the most appropriate meaning of the given idiom.\n" +
                "Dead heat\n ",
                " Strong opposition to one's ideas ", " Close contest that ends in a tie ",
                " A deadly blast of hot air ", " A strong heat wave ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q231);

        Question q232 = new Question("Given below are four jumbled sentences. Out of the given options pick the one that gives their correct order.\n" +
                "A. “We are going to the market,” declared Reetu and Geetu.\n" +
                "B. “Where are you going?” the father asked.\n" +
                "C. “Take your umbrella, it is going to rain,” the mother said.\n" +
                "D. “Yes, definitely. We will,” replied the two. ",
                " DCAB ", " BCDA ", " ABDC ", " BACD ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q232);

        Question q233 = new Question("Select the most appropriate segment to correct the given sentence. If correction is not required select ‘no improvement’.\n" +
                "The animal resembled with a cat ",
                " No improvement ", " resembled by ", " resembled to ", " resembled ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q233);

        Question q234 = new Question("Select the correct direct form of the given sentence.\n" +
                "The teacher commanded the students not to shout ",
                " The teacher told to the students, \"You must not shout.” ",
                "  The teacher said to the students, \"Don’t shout.” ",
                " The teacher says to the students, \"Do not shout.\" ",
                " The teacher said to the student, \"You should not shout.” ",
                2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q234);

        Question q235 = new Question("In the sentence identify the segment which contains the grammatical error.\n" +
                "The boy which stole the money was caught by the police. ",
                " stole the money ", " by the police ", " was caught ", " The boy which ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q235);

        Question q236 = new Question("In the sentence identify the segment which contains the grammatical error.\n" +
                "Saraswati college has maintained its reputation as one of the best college in the country. ",
                " one of the best college ", " in the country ", " Saraswati college has maintained ", " its reputation as ", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q236);

        Question q237 = new Question("Select one word for the following group of words.\n" +
                "Morals that govern one's behavior ",
                " Psychology ", " Ethics ", " Attitude ", " Intuition ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q237);

        Question q238 = new Question("Select the synonym of the given word.\n" +
                "REVERE ",
                " Respect ", " Repeat ", " Enjoy ", " Condemn ", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q238);

        Question q239 = new Question("Select the most appropriate word to fill in the blank.\n" +
                "The groom stood before the ______ for the wedding ceremony at the church.\n ",
                " altar ", " alter ", " atlas ", " attic ", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q239);

        Question q240 = new Question("Select one word for the following group of words.\n" +
                "Open refusal to obey orders ",
                " Obedience ", " Defiance ", " Compliance ", " Adherence ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q240);

        Question q241 = new Question("Given below are four jumbled sentences. Out of the given options pick the one that gives their correct order.\n" +
                "A. Eventually, she overcame adversities and achieved success.\n" +
                "B. She engaged herself in ‘earn while you learn’, finance scheme in her college.\n" +
                "C. She needed financial support to complete her graduation.\n" +
                "D. Rama was a very poor girl.\n ",
                " DCBA ", " CBDA ", " ADCB ", " ABCD ", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q241);

        Question q242 = new Question("Select the antonym of the given word.\n" +
                "BROAD ",
                " Wide ", " Large ", " Long ", " Narrow ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q242);







        //GENERAL AWARENESS 2 - 2019


        Question q243 = new Question("Lt. General _______ took charge as the Chief of Army Staff on 31 December 2019.\n ",
                " Ravendra Pal Singh ", " Manoj Mukund Naravane ", " Anil Chauhan ", " Bipin Rawat ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q243);

        Question q244 = new Question("The Harshacharita is a biography of Harshavardhana, the ruler of Kannauj, composed\n" +
                "in Sanskrit by his court poet, _______.\n ",
                " Banabhatta ", " Kamban ", " Dandin ", " Jinsena ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q244);

        Question q245 = new Question("Who was the President of the World Bank Group as of January, 2020?\n ",
                " Paul Wolfowitz ", " David Malpass ", " Jim Yong Kim ", " Robert Zoellick ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q245);

        Question q246 = new Question("The Gol Gumbad (Gumbaz) of ________ is the mausoleum of Muhammad Adil Shah.\n ",
                " Bijapur ", " Delhi ", " Agra ", " Allahabad ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q246);

        Question q247 = new Question("Private ownership of the means of production is a feature of a _______ economy.\n ",
                " socialist ", " dual ", " capitalist ", " mixed ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q247);

        Question q248 = new Question(" _________ was the capital of Magadha before the 4th century BCE.\n ",
                " Mathura ", " Pataliputra ", " Varanasi ", " Rajagaha ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q248);

        Question q249 = new Question("Asia's largest wholesale spice market is located in _______. ",
                " Delhi ", " Kolkata ", " Ahmedabad ", " Bengaluru ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q249);

        Question q250 = new Question("The Vedic Civilisation in India flourished along the river__________.\n ",
                " Godavari ", " Saraswati ", " Tapi ", " Narmada ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q250);

        Question q251 = new Question("The 14th Dalai Lama resides in _______. ",
                " Gangtok ", " Kalimpong ", " Dharamsala ", " Shillong ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q251);

        Question q252 = new Question("In May 2019, the International Monetary Fund agreed to bail out ________ with a fund of $6 billion. ",
                " India ", " Bangladesh ", " Pakistan ", " Nepal ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q252);

        Question q253 = new Question("In the 4th century BCE, the capital of Magadha was shifted to ________.\n ",
                " Panipat ", " Varanasi ", " Pataliputra ", " Mathura ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q253);

        Question q254 = new Question("The ________ lake in Gujarat was an artificial reservoir built during the rule of the Mauryas.\n ",
                " Pushkar ", " Lonar ", " Loktak ", " Sudarshana ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q254);

        Question q255 = new Question("Which of the following is NOT a folk dance belonging to the union territory of Jammu and Kashmir?\n ",
                " Dhumal ", " Hafiza ", " Dangi ", " Rouf ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q255);

        Question q256 = new Question("The Biraja Temple, the Rajarani Temple and the Samaleswari Temple are all located in ________.\n ",
                " Odisha ", " Tamil Nadu  ", " Assam ", " Kerala ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q256);

        Question q257 = new Question("Who among the following is an Indian Olympic archer and Padma Shri winner?\n ",
                " Balbir Singh Dosanjh  ", " Bajrang Punia ", " Limba Ram ", " Kidambi Srikanth ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q257);

        Question q258 = new Question("King Harshavardhana ascended the throne of Thaneshwar and Kannauj on the death of his brother, ________.\n ",
                " Rajyavardhana ", " Chandravardhana ", " Indravardhana ", " Suryavardhana ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q258);

        Question q259 = new Question("Planetary scientists call the thin gaseous envelope around the Moon as the _______. ",
                " lunar endosphere ", " lunar thermosphere ", " lunar stratosphere ", " lunar exosphere  ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q259);

        Question q260 = new Question("Xerophthalmia is caused due to the deficiency of vitamin ________.\n ",
                " A ", " K ", " C ", " D ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q260);

        Question q261 = new Question("Which Article of the Indian Constitution prohibits discrimination on the grounds of religion, race, caste, sex and place of birth? ",
                " Article 25  ", " Article 19 ", " Article 23 ", " Article 15 ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q261);

        Question q262 = new Question("Article 17 of the Constitution of India deals with the abolition of ________.\n ",
                " slavery ", " untouchability ", " titles ", " sati ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q262);

        Question q263 = new Question("In April 2019, scientists in ________ produced the world’s first 3D printed heart using human tissue.\n ",
                " Ethiopia ", " Israel ", " Kenya ", " Croatia ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q263);

        Question q264 = new Question(" _______ expansion makes the Eiffel Tower taller during summers. ",
                " Chemical ", " Thermal ", " Gravitational ", " Gradient ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q264);

        Question q265 = new Question("According to the United Nations' World Economic Situation and Prospects Report, 2019, the Indian economy is expected to expand by _____ in 2020.\n ",
                " 7.8% ", " 7.6% ", " 7.2% ", " 7.1% ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q265);

        Question q266 = new Question("The major component of modern Olympic gold medals is ________. ",
                " Silver ", " Copper ", " Bronze ", " Gold ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q266);

        Question q267 = new Question("In biological terms, _______ is a relationship between two organisms in which one organism benefits and the other is unaffected. ",
                " Amensalism ", " Commensalism ", " Parasitism ", " Mutualism ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_2, Question.YEAR_2019);
        addQuestion(q267);









        //ENGLISH 3 - 2019

        Question q268 = new Question("Select the word which means the same as the given group of words.\n" +
                "A sudden rush of a large number of frightened people or animals.\n ",
                " Stampede ", " Lunacy ", " Scapegoat ", " Recluse ", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q268);

        Question q269 = new Question("Select the most appropriate meaning of the given Idiom.\n" +
                "The bee’s knees ",
                " Problematic  ", " Foolish ", " Extraordinary ", " Observant ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q269);

        Question q270 = new Question("Select the most appropriate word to fill in the blank.\n" +
                "A reward is a ______ which motivates a person to achieve excellence in his field.\n ",
                " recognition ", " memorial ", " collection ", " monument ", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q270);

        Question q271 = new Question(" Select the most appropriate ANTONYM of the given word.\n" +
                "Obsolete",
                " Rigid ", " Outdated ", " Remote ", " Recent ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q271);

        Question q272 = new Question("Select the word which means the same as the given group of words.\n" +
                "One who loads and unloads ships. ",
                " Spinster ", " Stevedore ", " Rustic ", " Captain ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q272);

        Question q273 = new Question(" Select the correctly spelt word.\n",
                " Conscinteous ", " Encouragement ", " Comotion ", " Embarasment ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q273);

        Question q274 = new Question("Select the most appropriate ANTONYM of the given word.\n" +
                "Derogatory ",
                " Intricate ", " Complimentary ", " Insulting ", " Depreciating ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q274);

        Question q275 = new Question("Select the most appropriate word to fill in the blank.\n" +
                "The government should take stringent steps against terrorists and foil their ______ designs.\n ",
                " exemplary ", " conducive ", " benevolent ", " malicious ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q275);

        Question q276 = new Question("Select the most appropriate meaning of the given idiom.\n" +
                "To throw a fit\n",
                " Faint and fall down ", " Become unconscious ", " Express extreme anger ", "  Caution someone about fitness ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q276);

        Question q277 = new Question("In the sentence identify the segment which contains the grammatical error.\n" +
                "Those who follow a healthy routine is likely enjoying good health.  ",
                " Those who follow ", " a healthy routine ", " is likely enjoying  ", " good health ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q277);

        Question q278 = new Question("Given below are four jumbled sentences. Out of the given options pick the one that gives their correct order.\n" +
                "A. They can then purchase them on subsidized rates with additional loan facilities.\n" +
                "B. It will import technologically advanced medical instruments and provide them to\n" +
                "entrepreneurs.\n" +
                "C. The Indian Government has announced certain facilities in the budget session.\n" +
                "D. This will help in strengthening the economic condition of entrepreneurs.\n",
                " BDCA ", " DCAB ", " CBAD ", " CADB ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q278);

        Question q279 = new Question("Select the most appropriate option to correct the given sentence. If no correction is required, select No improvement.\n" +
                "The mathematical calculation of this problem is easy than a previous one.\n ",
                " easiest than the ", " No Improvement ", " easy than the ", " easier than the ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q279);

        Question q280 = new Question("Select the most appropriate synonym of the given word.\n" +
                "Acknowledgement ",
                " Confusion ", " Elimination ", " Compensation ", " Confirmation ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q280);

        Question q281 = new Question(" In the sentence identify the segment which contains the grammatical error.\n" +
                "When I reached the cinema hall, the movie had already began.\n ",
                " the cinema hall ", " When I reached ", " the movie had  ", " already began ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q281);

        Question q282 = new Question("Select the correct indirect form of the given sentence.\n" +
                "The teacher said to me, “You have not submitted the assignment.”\n ",
                " The teacher told to me that I have not submitted that assignment.\n ",
                " The teacher said to me that I have not submitted the assignment. ",
                " The teacher said me that I had not submitted the assignment. ",
                " The teacher told me that I had not submitted the assignment. ",
                4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q282);

        Question q283 = new Question(" Select the correctly spelt word.\n",
                " Employeed ", " Rehersal ", " Veterinary ", " Seperable ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q283);

        Question q284 = new Question("Select the correct passive form of the given sentence.\n" +
                "His elder sister taught him English.  ",
                " His elder sister is taught English by him.\n ",
                " He is being taught English by his elder sister.\n ",
                " He was taught English by his elder sister. ",
                " He has been taught English by his elder sister.\n  ",
                3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q284);

        Question q285 = new Question("Select the most appropriate option to correct the given sentence.\n" +
                "No effort has been made by the Indian cricket team to cash off on its vibrant image in the World Cup.\n ",
                "  for cash through in ", "  for cashing off on ", "  to cash in on ", "  to cash up on ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q285);

        Question q286 = new Question("Given below are four jumbled sentences. Out of the given options pick the one that gives their correct order.\n" +
                "A. This is because of its aroma, flavour and variety in the market.\n" +
                "B. Thus, it leads to poor health and mental disorders among children.\n" +
                "C. Children as well as teenagers are tempted towards junk food.\n" +
                "D. It has no or negligible nutritional value and high content of sugar and salt. ",
                " CDAB ", " BCDA ", " CADB ", " ACDB ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q286);

        Question q287 = new Question("Select the most appropriate synonym of the given word.\n" +
                "Prodigal ",
                " Trivial ", " Extravagant ", " Arrogant ", " Humble  ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q287);








        //GENERAL AWARENESS 3 - 2019


        Question q288 = new Question("Georg Simon Ohm in whose honour we have the famous Ohm’s Law, hailed from which country?\n ",
                " Russia ", " Spain ", " Poland ", " Germany ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q288);

        Question q289 = new Question("Which Union Minister of Home Affairs released a book titled Karmayodha Granth in New Delhi? ",
                " P Chidambaram ", " Sushilkumar Shinde ", " Amit Shah ", " Rajnath Singh ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q289);

        Question q290 = new Question("Who was the first Governor of Madhya Pradesh? ",
                " BD Sharma ", "  NN Wanchu ", " GP Singh ", " Dr. Sitaramayya  ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q290);

        Question q291 = new Question(" Which part of the body is responsible for the manufacture of red blood cells?",
                " Brain ", " Lungs ", " Bone marrow ", " Heart ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q291);

        Question q292 = new Question("Which city of India is known as 'The Athens of the East'? ",
                " Kochi ", " Allahabad ", " Patna ", " Madurai ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q292);

        Question q293 = new Question("Methane is a colourless, odourless, non-toxic but flammable gas. What is its common name? ",
                " Blue vitriol ", " Heating gas ", " Marsh gas ", " Laughing gas ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q293);

        Question q294 = new Question("In which state did the second phase of Intensified Mission Indradhanush (IMI) 2.0 begin in January 2020? ",
                " Uttar Pradesh ", " Punjab  ", " Kerala ", " Bihar ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q294);

        Question q295 = new Question("Which of the following is NOT a twin city of India?\n ",
                " Cuttack and Bhubaneswar ", " Hubli and Dharwad ", " Thrissur and Thiruvalla ", " Ahmedabad and Gandhinagar ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q295);

        Question q296 = new Question("John Maynard Keynes, best known for his economic theories (Keynesian economics), hailed from which country? ",
                " Sweden ", " Denmark ", " Australia ", " England ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q296);

        Question q297 = new Question("In the sequence of planets in the solar system, which planet comes in between Mars and Saturn? ",
                " Uranus ", " Mercury ", " Venus ", " Jupiter ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q297);

        Question q298 = new Question("In which state has the Jawara Dance, a dance form to celebrate wealth, originated? ",
                " Gujarat ", " Kerala ", " Madhya Pradesh  ", " Rajasthan ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q298);

        Question q299 = new Question(" In which city was the Jhanda Satyagraha or Flag Satyagraha of 1923 held? ",
                " Calcutta ", " Nagpur ", " Ahmedabad ", " Bombay ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q299);

        Question q300 = new Question("The development of a fruit without fertilization is called ______.\n ",
                " Gametogamy ", " Parthenocarpy ", " Hybridogenesis ", " Apomixis ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q300);

        Question q301 = new Question(" Which city in India is world renowned for one of the most traditional embroidery styles, Chikankari?",
                " Udaipur ", " Hyderabad ", " Ahmedabad ", " Lucknow ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q301);

        Question q302 = new Question("Who is the first Indian to bag two International hat-tricks in cricket? ",
                " Rohit Sharma  ", " Virat Kohli ", " Kedar Jadhav ", " Kuldeep Yadav ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q302);

        Question q303 = new Question("Freedom fighter Sucheta Kripalani, became the first woman chief minister of which state? ",
                " Uttar Pradesh ", " Rajasthan  ", " Andhra Pradesh ", " Gujarat ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q303);

        Question q304 = new Question(" In which period was the legendary Victoria Terminus station (currently Chhatrapati Shivaji Maharaj Terminus), Mumbai built?",
                " 1878 to 1888 ", " 1911 to 1921 ", " 1933 to 1943 ", " 1843 to 1853 ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q304);

        Question q305 = new Question("Who chaired the sixth meeting of the Island Development Agency in New Delhi in January 2020?\n ",
                " Narendra Modi ", " Nirmala Sitharaman ", " Amit Shah ", " Nitin Gadkari ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q305);

        Question q306 = new Question(" Who was chosen as foreign secretary of India in January 2020?",
                " Ranjan Mathai ", " Harsh Vardhan Shringla ", " Vijay Keshav Gokhale ", " Nirupama Rao ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q306);

        Question q307 = new Question("Jellyfish are an example of which type of phylum?\n ",
                " Phylum - Cnidaria ", " Phylum -Porifera ", " Phylum -Protozoa ", " Phylum -Ctenophora ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q307);

        Question q308 = new Question("Which Tennis star will have a Swiss coin minted in his/her honour?\n ",
                " Serena Williams ", " Rafael Nadal ", " Novak Djokovic ", " Roger Federer ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q308);

        Question q309 = new Question(" Which US based Indian topped the Forbes India's ‘20 people to watch in the 2020s’ list?",
                " Hasan Minhaj ", " Prashant Kishor  ", " Mahua Moitra ", " Dushyant Chautala ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q309);

        Question q310 = new Question("Which of the following is NOT a nationalised bank?  ",
                " State Bank of India  ", " Punjab National Bank ", " United Bank of India ", " Punjab and Sind Bank  ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q310);

        Question q311 = new Question("Who was appointed as Managing Director of the International Monetary Fund in October, 2019? ",
                " Kristalina Georgieva ", " Christine Lagarde ", " Rodrigo Rato ", " Dominique Strauss-Kahn ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q311);

        Question q312 = new Question("Which pillar inscriptions has recorded the achievements of Samudra Gupta, who was known as the 'Napoleon of India' for his conquests?\n ",
                " Iron Pillar ", "  Vijaya Stambha ", " Allahabad Pillar ", " Sun Pillar ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_3, Question.YEAR_2019);
        addQuestion(q312);








        //ENGLISH 4 - 2019

        Question q313 = new Question("Given below are four jumbled sentences. Out of the given options pick the one that gives their correct order.\n" +
                "A. Upon returning from his travels, he was forced to live in a house where his large\n" +
                "family lived.\n" +
                "B. Vaikom Muhammad Basheer was a Malayalam fiction writer from Vaikom in Kerala.\n" +
                "C. The household was always noisy and full of chaos, no place for a writer surely!\n" +
                "D. Apart from family members, myriads of domestic animals also treated the house as\n" +
                "their own.  ",
                " BCDA ", " BCAD ", " BADC ", " BDCA ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q313);

        Question q314 = new Question("Select the INCORRECTLY spelt word.\n ",
                " Impeach ", " Influence ", " Itinerent ", " Ignorance ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q314);

        Question q315 = new Question("Select the most appropriate option to fill in the blank.\n" +
                "Being a millionaire, he is leading a ______ life.\n ",
                " expensive ", " luxurious ", " destitute ", " conducive ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q315);

        Question q316 = new Question("Select the correct passive form of the given sentence.\n" +
                "Did the problems you had to face discourage you? ",
                " Have you been discouraged by the problems you have to face? ",
                " Are you discouraged by the problems you had to face?\n ",
                " Were you discouraged by the problems you had to face? ",
                " Are you being discouraged by the problems you had to face? ",
                3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q316);

        Question q317 = new Question("Select the word which means the same as the group of words given.\n" +
                "One who is preoccupied with his own interests ",
                " Pessimist ", " Optimist ", " Atheist ", " Egoist ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q317);

        Question q318 = new Question(" Select the most appropriate option to fill in the blank.\n" +
                "Children under five years are ______ from passport biometrics.",
                " allowed ", " escaped ", " acquitted ", " exempted ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q318);

        Question q319 = new Question("Select the INCORRECTLY spelt word.\n ",
                " Deter ", " Diliver ", " Decision ", " Denial ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q319);

        Question q320 = new Question("In the sentence identify the segment which contains the grammatical error.\n" +
                "I am believing you have submitted all the necessary documents.\n ",
                " all the ", " necessary documents ", " you have submitted ", " I am believing ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q320);

        Question q321 = new Question("Select the most appropriate option to correct the given sentence.\n" +
                "Your advice will benefit to me. ",
                " benefit from me ", " benefit for me ", " No substitution ", " benefit me ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q321);

        Question q322 = new Question("In the sentence identify the segment which contains the grammatical error.\n" +
                "No sooner did we receive your message when we heaved a sigh of relief.\n ",
                " did we receive ", " a sigh of relief ", " your message ", " when we heaved ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q322);

        Question q323 = new Question("Select the most appropriate meaning of the given idiom.\n" +
                "Hold water ",
                " To be fickle ", " To be valid ", " To be busy ", " To be deep ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q323);

        Question q324 = new Question("Select the most appropriate synonym of the given word.\n" +
                "Solitary ",
                " Stubborn ", " Sensible ", " Splendid ", " Singular ", 4, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q324);

        Question q325 = new Question("Select the correct indirect form of the given sentence.\n" +
                "The lawyer said to me, \"There is no proof of your involvement in this case.\"",
                " The lawyer said me that there was no proof of my involvement in this case.\n ",
                " The lawyer told me that there was no proof of my involvement in that case. ",
                " The lawyer told that there is no proof of my involvement in that case.\n ",
                " The lawyer told me that there is no proof of your involvement in this case. ",
                2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q325);

        Question q326 = new Question(" Select the most appropriate ANTONYM of the given word.\n" +
                "Friendship",
                " Amity ", " Slavery ", " Enmity ", " Arrogance ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q326);

        Question q327 = new Question(" Given below are four jumbled sentences. Out of the given options pick the one that gives their correct order.\n" +
                "A. Even the most ill-equipped laboratory would have been better than their shed.\n" +
                "B. Thus, they did not allow any difficulties to come in their way.\n" +
                "C. But their mind was set upon the discovery of radium.\n" +
                "D. The Curies had to work in extreme poverty.\n",
                " ADBC ", " DBCA ", " DACB ", " ABCD ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q327);

        Question q328 = new Question("Select the most appropriate option to correct the given sentence.\n" +
                "Where you left your bag yesterday? ",
                " No substitution ", " Where did you left ", " Where did you leave ", " Where were you leaving ", 3, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q328);

        Question q329 = new Question("Select the most appropriate synonym of the given word.\n" +
                "Fury ",
                " Anger ", " Risk ", " Sin ", " Crime ", 1, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q329);

        Question q330 = new Question("Select the word which means the same as the group of words given.\n" +
                "A geometrical figure with eight sides ",
                " Hexagon ", " Octagon ", " Pentagon ", " Heptagon ", 2, Question.SUBJECT_ENGLISH, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q330);








        //GENERAL AWARENESS 4 - 2019


        Question q331 = new Question(" Former union minister and former Karnataka CM, D.V. Sadananda Gowda is a cabinet minister in the current central cabinet (February-2020). What is his portfolio?",
                " Tribal Affairs ", " Law and Justice ", " Public Distribution ", " Chemicals and Fertilizers ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q331);

        Question q332 = new Question("The city of Vijayawada lies on the banks of which of these rivers?\n ",
                " Mahanadi ", " Tapti ", " Godavari ", " Krishna ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q332);

        Question q333 = new Question("The American scientist Edwin Hubble's name is associated with which of these theories? ",
                " Partial Coherence of Light Theory ", " Lattice Gauge Theory ", " The Big Bang Theory ", " Quantum Chromodynamics Theory ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q333);

        Question q334 = new Question("When does the entire earth experience equal days and nights? ",
                " Day of equinox ", " Day of winter solstice ", " At orbital plane ", " Day of summer solstice ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q334);

        Question q335 = new Question("Bhavai and Kalbelia as traditional dance forms, owe their genesis to which Indian state? ",
                " Punjab ", " Odisha ", " Assam ", " Rajasthan ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q335);

        Question q336 = new Question("Iranian Major General Qasem Soleimani was recently (2020) assassinated by the US military in ______. ",
                " United Arab Emirates ", " Iraq ", " Pakistan ", " Saudi Arabia ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q336);

        Question q337 = new Question("Which of the following is an Indian Research Station in the Antarctica Region? ",
                " Maitri ", " Orcadas ", " Mawson ", " Hope Bay ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q337);

        Question q338 = new Question("Only one Indian batsman has scored a triple century in test cricket other than Virender Sehwag. Name this batsman. ",
                " Shikhar Dhawan ", " Rohit Sharma ", " Karun Nair ", " Ajinkya Rahane ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q338);

        Question q339 = new Question("Who is the only scientist in the world to have won the Nobel prize in Chemistry twice? ",
                " Linus Carl Pauling ", " Frederick Sanger ", " Roger D. Kornberg ", " Madame Curie ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q339);

        Question q340 = new Question("The recently revoked 'Article 370' is associated with which of these states of India? ",
                " Assam ", " Sikkim ", " Nagaland ", " Kashmir ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q340);

        Question q341 = new Question("Who was the then Governor-General of British India, when ‘Sati Pratha’ became illegal and punishable? ",
                " Lord William Bentinck ", " Warren Hastings ", " Lord Wellesley ", " Lord Cornwallis ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q341);

        Question q342 = new Question("Name the two Indian actors who shared the National Best Actor Award (Male) in the 66th National Film Awards 2019.\n ",
                " Ayushmann Khurrana and Vicky Kaushal ", " Ranbir Kapoor and Akshay Kumar ", " Amitabh Bachchan and Ranbir Kapoor ", " Nana Patekar and Mohanlal ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q342);

        Question q343 = new Question("Which of the following is an INCORRECT sequence of Mughal rulers? ",
                " Babur, Humayun, Akbar ", " Jahangir, Shah Jahan, Aurangzeb ", " Akbar, Jahangir, Shah Jahan ", " Akbar, Shah Jahan, Jahangir ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q343);

        Question q344 = new Question("From which of the following states does 2019 Padma Vibhushan winner, Teejan Bai hail? ",
                " Chhattisgarh ", " Odisha ", " Gujarat ", " Telangana ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q344);

        Question q345 = new Question("Which of these is the energy conversion that happens in the process called photosynthesis? ",
                " Light energy to chemical energy ", " Potential energy to chemical energy ", " Heat energy to chemical energy ", " Heat energy to light energy ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q345);

        Question q346 = new Question("The 3rd Khelo India Youth Games 2020 is hosted by which Indian state? ",
                " Kerala ", " Punjab ", " Assam ", " Karnataka ", 3, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q346);

        Question q347 = new Question("Name the company that has acquired an online travel portal Yatra Online Inc., for an enterprise value of $337.8 million, in an all-stock transaction.\n ",
                " Trip Advisor ", " Ebix Inc. ", " Make my trip.com ", " Trivago ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q347);

        Question q348 = new Question("What is the name of the phenomena (driven by the scattering of light) in which mountain tops acquire a rosy or orange hue around sunrise and sunset?\n ",
                " Circle of confusion ", " Barrel distortion ", " Brillouin scattering ", " Alpenglow ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q348);

        Question q349 = new Question("Who among the following is the current (January 2020) Governor of Kerala? ",
                " Lalji Tandon  ", " B.D. Mishra ", " Satya Pal Mallik ", " Arif Mohammed Khan ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q349);

        Question q350 = new Question("Name the author of the 2019 released book - 'The Scent of God'. ",
                " Himanjali Sankar ", " Saikat Majumdar ", " Githa Hariharan ", " Nayantara Sehgal ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q350);

        Question q351 = new Question(" How many members did the International Monetary Fund (IMF) have as of January 2020?",
                " 164 ", " 182 ", " 174 ", " 189 ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q351);

        Question q352 = new Question("What is the name of the phenomena in physics and astronomy which involves the splitting of a spectral line into two or more components of slightly different frequency when the light source is placed in a magnetic field?\n ",
                " Raman Effect ", " Lumen Effect ", " Alpenglow Effect ", " Zeeman Effect ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q352);

        Question q353 = new Question("Who is the author of the delightful and anecdotal history of Indian cricket titled - 'A Corner of a Foreign Field: The Indian History of a British Sport'?\n ",
                " Ramachandra Guha ", " Romila Thapar ", " Sanjay Singh ", " Bipin Chandra ", 1, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q353);

        Question q354 = new Question(" Who among the following is known as the 'father of Muslim renaissance' in Bengal?",
                " Sir Sayed Ahmed Khan ", " Ameer Ali ", " Nawab Salimullah Khan ", " Nawab Abdul Latif Khan ", 4, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q354);

        Question q355 = new Question("Four multi-storied illegal constructions - Jain Coral Cove, H20 Holy Faith, Alfa Serene and Golden Kayaloram - were razed to the ground in January 2020 following Supreme Court instructions. In which state did this happen? ",
                " Karnataka ", " Kerala ", " Tamil Nadu ", " Goa ", 2, Question.SUBJECT_GENERAL_AWARENESS, Exam.SSC_CGL_4, Question.YEAR_2019);
        addQuestion(q355);



    }

    private void addQuestion(Question question){
        ContentValues cv = new ContentValues();
        cv.put(QuestionsTable.COLUMN_QUESTION, question.getQuestion());
        cv.put(QuestionsTable.COLUMN_OPTION1, question.getOption1());
        cv.put(QuestionsTable.COLUMN_OPTION2, question.getOption2());
        cv.put(QuestionsTable.COLUMN_OPTION3, question.getOption3());
        cv.put(QuestionsTable.COLUMN_OPTION4, question.getOption4());
        cv.put(QuestionsTable.COLUMN_ANSWER_NUMBER, question.getAnswerNr());
        cv.put(QuestionsTable.COLUMN_SUBJECT, question.getSubject());
       cv.put(QuestionsTable.COLUMN_YEAR, question.getYear());
        cv.put(QuestionsTable.COLUMN_EXAM_ID, question.getExamId());
        db.insert(QuestionsTable.TABLE_NAME, null, cv);
    }

    public List<Exam> getAllExam() {
        List<Exam> examList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + ExamTable.TABLE_NAME, null);

        if (c.moveToFirst()){
            do {
                Exam exam = new Exam();
                exam.setId(c.getInt(c.getColumnIndex(ExamTable._ID)));
                exam.setName(c.getString(c.getColumnIndex(ExamTable.COLUMN_NAME)));
                examList.add(exam);
            }while (c.moveToNext());
        }
        c.close();
        return examList;
    }

    public ArrayList<Question> getAllQuestions(){
        ArrayList<Question> questionList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + QuestionsTable.TABLE_NAME, null);
        if (c.moveToFirst()){
            do {
                Question question = new Question();
                question.setId(c.getInt(c.getColumnIndex(QuestionsTable._ID)));
                question.setQuestion(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_QUESTION)));
                question.setOption1(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION1)));
                question.setOption2(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION2)));
                question.setOption3(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION3)));
                question.setOption4(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION4)));
                question.setAnswerNr(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_ANSWER_NUMBER)));
                question.setSubject(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_SUBJECT)));
                question.setSubject(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_YEAR)));
                question.setExamId(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_EXAM_ID)));
                questionList.add(question);
            }while (c.moveToNext());
        }
        c.close();
        return questionList;
    }

    public ArrayList<Question> getQuestions(int examID, String subject, String year){
        ArrayList<Question> questionList = new ArrayList<>();
        db = getReadableDatabase();

        String selection = QuestionsTable.COLUMN_EXAM_ID + " = ? " + " AND " +
                QuestionsTable.COLUMN_SUBJECT + " = ? " + " AND " +
                QuestionsTable.COLUMN_YEAR + " = ? ";

        String[] selectionArgs = new String[]{ String.valueOf(examID), subject, year};
        Cursor c = db.query(QuestionsTable.TABLE_NAME, null, selection, selectionArgs, null, null, null);

        if (c.moveToFirst()){
            do {
                Question question = new Question();
                question.setId(c.getInt(c.getColumnIndex(QuestionsTable._ID)));
                question.setQuestion(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_QUESTION)));
                question.setOption1(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION1)));
                question.setOption2(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION2)));
                question.setOption3(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION3)));
                question.setOption4(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION4)));
                question.setAnswerNr(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_ANSWER_NUMBER)));
                question.setSubject(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_SUBJECT)));
                question.setSubject(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_YEAR)));
                question.setExamId(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_EXAM_ID)));
                questionList.add(question);
            }while (c.moveToNext());
        }
        c.close();
        return questionList;
    }
}
