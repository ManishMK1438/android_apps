package com.MYQ.myquiz;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

public class SettingsActivity extends AppCompatActivity {

   // private TextView about;
    private TextView contactUs;
    private TextView terms;
    private TextView appVersion;
    private TextView verifyEmail;
    private TextView deleteAccount;

    private FirebaseAuth mAuth;
    private FirebaseUser mUser;

    private InterstitialAd mInterstitialAd1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        initialization();

        mAuth = FirebaseAuth.getInstance();
        mUser = FirebaseAuth.getInstance().getCurrentUser();

        interstitialAd();
/*
        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               OpenAboutActivity();

            }
        });
*/
        contactUs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenContactActivity();
            }
        });

        terms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenTermsActivity();
            }
        });

        appVersion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenAppVersionActivity();
            }
        });

        verifyEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                VerifyEmail();
            }
        });

        deleteAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeleteAccount();
            }
        });


    }

    private void interstitialAd() {
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {

            }
        });
        mInterstitialAd1 = new InterstitialAd(this);
        mInterstitialAd1.setAdUnitId("ca-app-pub-3940256099942544/1033173712");

        mInterstitialAd1.loadAd(new AdRequest.Builder().build());

        mInterstitialAd1.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                // Load the next interstitial.
                mInterstitialAd1.loadAd(new AdRequest.Builder().build());
            }

        });
    }



    private void OpenAboutActivity() {
        Intent intent = new Intent(SettingsActivity.this, AboutActivity.class);
        startActivity(intent);
    }

    private void OpenContactActivity() {
        Intent intent = new Intent(SettingsActivity.this, ContactUsActivity.class);
        startActivity(intent);
    }

    private void OpenTermsActivity() {
        Intent intent = new Intent(SettingsActivity.this, TermsOfServicesActivity.class);
        startActivity(intent);
    }

    private void OpenAppVersionActivity() {
        Intent intent = new Intent(SettingsActivity.this, AppVersionActivity.class);
        startActivity(intent);
    }

    private void VerifyEmail(){
        mUser.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()){
                    mAuth.signOut();
                    sendUserToStartingScreenActivity();
                    Toast.makeText(SettingsActivity.this, "Verification Email sent to your Email inbox. Please Log In again after verifying", Toast.LENGTH_LONG).show();

                    if (mInterstitialAd1.isLoaded()) {
                        mInterstitialAd1.show();
                    } else {
                        Log.d("TAG", "The interstitial wasn't loaded yet.");
                    }

                }else {
                    String message = Objects.requireNonNull(task.getException()).getMessage();
                    Toast.makeText(SettingsActivity.this, "ERROR : " + message, Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        assert user != null;
        if (user.isEmailVerified()) {
            verifyEmail.setText("Email Is Verified");
            verifyEmail.setTextColor(Color.GREEN);
            verifyEmail.setClickable(false);
        }
    }

    private void DeleteAccount() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this)
                .setTitle("WARNING!!!")
                .setMessage("Are you sure you want to delete your account? This process cannot be undone!")
                .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                })
                .setCancelable(true)
                .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                        user.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()){
                                    sendUserToStartingScreenActivity();
                                    Toast.makeText(SettingsActivity.this, "Account Deleted Successfully!!", Toast.LENGTH_SHORT).show();
                                }else{
                                    String message = Objects.requireNonNull(task.getException()).getMessage();
                                    Toast.makeText(SettingsActivity.this, "ERROR : " + message, Toast.LENGTH_LONG).show();
                                }
                            }
                        });
                        String firebaseUser = FirebaseAuth.getInstance().getCurrentUser().getUid();
                        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users").child(firebaseUser);
                        reference.removeValue();
                    }
                });
        dialog.show();

    }

    private void sendUserToStartingScreenActivity() {
        Intent intent = new Intent(SettingsActivity.this, StartingScreenActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void initialization() {
       // about = findViewById(R.id.text_view_about);
        contactUs = findViewById(R.id.text_view_contact_us);
        terms = findViewById(R.id.text_view_terms);
        appVersion = findViewById(R.id.text_view_app_version);
        verifyEmail = findViewById(R.id.text_view_verify_email);
        deleteAccount = findViewById(R.id.text_view_delete_account);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        if (mInterstitialAd1.isLoaded()) {
            mInterstitialAd1.show();
        } else {
            Log.d("TAG", "The interstitial wasn't loaded yet.");
        }

    }
}
