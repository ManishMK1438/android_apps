package com.MYQ.myquiz;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;


import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_SUBJECT = "extraSubject";
    public static final String EXTRA_EXAM_ID = "extraExamId";
    public static final String EXTRA_EXAM_NAME = "extraExamName";
   public static final String EXTRA_YEAR = "extraYear";

    private Button buttonStartQuiz;
    private FirebaseUser currentUser;
    private Toolbar toolbar;

    private Spinner spinnerExam;
    private Spinner spinnerSubject;
   private Spinner spinnerYear;

    private FirebaseAuth mAuth;

    private AdView mAdView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();

        Initialization();
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        loadExams();
        loadSubjects();
        loadYear();
        loadAd();



        buttonStartQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startQuiz();
            }
        });

    }

    private void loadAd() {
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
    }


    private void loadSubjects() {
        String[] subjectNames = Question.getAllSubjects();

        ArrayAdapter<String> adapterSubject = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, subjectNames);
        adapterSubject.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSubject.setAdapter(adapterSubject);
    }

    private void loadExams(){
        QuizDbHelper dbHelper = QuizDbHelper.getInstance(this);
        List<Exam> exams = dbHelper.getAllExam();

        ArrayAdapter<Exam> adapterExams = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, exams);
        adapterExams.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerExam.setAdapter(adapterExams);
    }

    private void loadYear(){
        String[] yearNames = Question.getAllYears();

        ArrayAdapter<String> adapterYear = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, yearNames);
        adapterYear.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerYear.setAdapter(adapterYear);
    }

    private void startQuiz() {
        Exam selectedExam = (Exam) spinnerExam.getSelectedItem();
        int examId = selectedExam.getId();
        String examName = selectedExam.getName();
        String subject = spinnerSubject.getSelectedItem().toString();
       String year = spinnerYear.getSelectedItem().toString();


        Intent intent = new Intent(MainActivity.this, QuizActivity.class);
        intent.putExtra(EXTRA_EXAM_ID, examId);
        intent.putExtra(EXTRA_EXAM_NAME, examName);
        intent.putExtra(EXTRA_SUBJECT, subject);
        intent.putExtra(EXTRA_YEAR, year);
        startActivity(intent);
    }

    private void Initialization() {
        buttonStartQuiz = findViewById(R.id.start_quiz_button);
        toolbar = findViewById(R.id.toolbar);
        spinnerSubject = findViewById(R.id.spinner_subject);
        spinnerExam = findViewById(R.id.spinner_exam);
        spinnerYear = findViewById(R.id.spinner_year);
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (currentUser == null){
            sendUserToStartingScreenActivity();
        }

    }

    private void sendUserToStartingScreenActivity() {
        Intent intent = new Intent(MainActivity.this, StartingScreenActivity.class);
        startActivity(intent);
    }

    private void sendUserToSettingsActivity(){
        Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
        startActivity(intent);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
         super.onCreateOptionsMenu(menu);

        getMenuInflater().inflate(R.menu.options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);

        if (item.getItemId() == R.id.rate_us_option){
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getPackageName())));
            }catch (ActivityNotFoundException e){
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
            }
            }


        if (item.getItemId() == R.id.settings_option){
            sendUserToSettingsActivity();
        }

        if (item.getItemId() == R.id.log_out_option){
            mAuth.signOut();
            sendUserToStartingScreenActivity();
        }
        return true;
    }

}
