package com.MYQ.myquiz;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

public class RegisterActivity extends AppCompatActivity {
    //private static final String TAG = "RegisterActivity" ;
    private EditText editTextUserName;
    private EditText editTextEmail;
    private EditText editTextPassword;
    private EditText editTextPhoneNumber;
    private Button buttonRegister;
   // private ImageView imageButtonCloseRegister;
    private FirebaseAuth mAuth;
    private DatabaseReference rootRef;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Initialization();

        mAuth = FirebaseAuth.getInstance();
        rootRef = FirebaseDatabase.getInstance().getReference();

        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });
/*
        imageButtonCloseRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this, StartingScreenActivity.class);
                startActivity(intent);
            }
        });
*/
    }

    private void registerUser(){

        final String name = editTextUserName.getText().toString().trim();
        final String email = editTextEmail.getText().toString().trim();
        final String password = editTextPassword.getText().toString().trim();
        final String phone = editTextPhoneNumber.getText().toString().trim();


        if (TextUtils.isEmpty(email) || (TextUtils.isEmpty(password)) || (TextUtils.isEmpty(phone))|| (TextUtils.isEmpty(name))){
            Toast.makeText(this, "Please fill all necessary details", Toast.LENGTH_SHORT).show();
        } else{
            progressDialog.setTitle("Creating New Account");
            progressDialog.setMessage("Please Wait...");
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()){
                                //String currentUserId = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
                                //rootRef.child("Users").child(currentUserId).setValue(helperClass);

                                sendUserToMainActivity();
                                Toast.makeText(RegisterActivity.this, "Account Created Successfully", Toast.LENGTH_SHORT).show();
                                progressDialog.dismiss();

                            }else {
                                String message = Objects.requireNonNull(task.getException()).getMessage();
                                Toast.makeText(RegisterActivity.this, "ERROR : " + message, Toast.LENGTH_LONG).show();
                                progressDialog.dismiss();
                            }
                        }
                    });
        }
    }

    private void sendUserToMainActivity() {
        Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }


    private void Initialization() {
        editTextUserName = findViewById(R.id.user_name);
        editTextEmail = findViewById(R.id.email_register);
        editTextPassword = findViewById(R.id.password_register);
        editTextPhoneNumber = findViewById(R.id.phone_number);
        buttonRegister = findViewById(R.id.button_register);
        //imageButtonCloseRegister = findViewById(R.id.close_button_register);
        progressDialog = new ProgressDialog(this);
    }
}
