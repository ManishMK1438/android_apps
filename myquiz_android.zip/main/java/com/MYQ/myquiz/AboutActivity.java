package com.MYQ.myquiz;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class AboutActivity extends AppCompatActivity {

    private EditText updateUserName;
    private EditText updateEmail;
    private EditText updatePhoneNumber;

    private TextView verifyEmail;
    //private TextView verifyPhone;

    private Button buttonUpdateUserName;
    private Button buttonUpdateEmail;
    private Button buttonUpdatePhone;
    private Button buttonVerifyEmail;
   // private Button buttonVerifyPhone;

    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private DatabaseReference rootRef;

    private String uId;
    private String userName;
    private String email;
    private String phoneNumber;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        mAuth = FirebaseAuth.getInstance();
        mUser = FirebaseAuth.getInstance().getCurrentUser();
        //rootRef = FirebaseDatabase.getInstance().getReference().child("Users");
        uId = mUser.getUid();


        initialization();
        UserHelperClass helperClass = new UserHelperClass();
        email = helperClass.getEmail();
        userName = helperClass.getUserName();
        phoneNumber = helperClass.getPhoneNumber();


        updateUserName.setText(userName);
       // updateUserName.setSelection(userName.length());
        updateEmail.setText(AboutActivity.this.email);
        //updateEmail.setSelection(email.length());
        updatePhoneNumber.setText(phoneNumber);
       // updatePhoneNumber.setSelection(phoneNumber.length());

/*
        rootRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    // userName = Objects.requireNonNull(dataSnapshot.child(uId).child("userName").getValue()).toString();
                  //   AboutActivity.this.email = Objects.requireNonNull(dataSnapshot.child(uId).child("email").getValue()).toString();
                    // phoneNumber = Objects.requireNonNull(dataSnapshot.child(uId).child("phoneNumber").getValue()).toString();


                updateUserName.setText(userName);
                updateUserName.setSelection(userName.length());
                updateEmail.setText(AboutActivity.this.email);
                //updateEmail.setSelection(email.length());
                updatePhoneNumber.setText(phoneNumber);
                updatePhoneNumber.setSelection(phoneNumber.length());

                }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(AboutActivity.this, "ERROR : " + databaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
*/

        if (mUser != null) {
            if (mUser.isEmailVerified()) {
                verifyEmail.setText("EMAIL IS VERIFIED");
                verifyEmail.setTextColor(Color.GREEN);
                //buttonVerifyEmail.setText("VERIFIED");
                buttonVerifyEmail.setEnabled(false);
            }
        }


        buttonUpdateUserName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(updateUserName.getText().toString().trim())) {
                    Toast.makeText(AboutActivity.this, "Please enter a valid name", Toast.LENGTH_SHORT).show();
                }else {
                    UpdateUserName();
                }
            }
        });

        buttonUpdateEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(updateEmail.getText().toString().trim())) {
                    Toast.makeText(AboutActivity.this, "Please enter a valid Email", Toast.LENGTH_SHORT).show();
                } else {
                    UpdateEmail();
                }
            }
        });

        buttonUpdatePhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(updatePhoneNumber.getText().toString().trim())) {
                    Toast.makeText(AboutActivity.this, "Please enter a valid number", Toast.LENGTH_SHORT).show();
                }else {
                    UpdatePhoneNumber();
                }
            }
        });

        buttonVerifyEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    VerifyEmail();
            }
        });
/*
        buttonVerifyPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                VerifyPhone();
            }
        });
*/
    }

    private void UpdateUserName() {
       if (updateUserName.getText().toString().isEmpty()) {
           Toast.makeText(this, "Please enter a valid name", Toast.LENGTH_SHORT).show();
        }else {
           rootRef.child("Users").child(uId).child("userName").setValue(updateUserName.getText().toString().trim());
           Toast.makeText(this, "User Name updated successfully", Toast.LENGTH_SHORT).show();
       }
    }
/*
    private boolean isNameChanged() {
        if (!userName.equals(updateUserName.getText().toString())){
            rootRef.child("Users").child(uId).child("userName").setValue(updateUserName.getText().toString().trim());

            return true;
        }else{
            return false;
        }
    }*/

    private void UpdateEmail(){
        if (isEmailChanged()) {
            String email = updateEmail.getText().toString().trim();
                mUser.updateEmail(updateEmail.getText().toString()).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(AboutActivity.this, "Email updated. Please VERIFY your Email", Toast.LENGTH_LONG).show();
                            verifyEmail.setText("VERIFY EMAIL");
                            verifyEmail.setTextColor(Color.WHITE);
                            buttonVerifyEmail.setEnabled(true);
                        } else {
                            String message = Objects.requireNonNull(task.getException()).getMessage();
                            Toast.makeText(AboutActivity.this, "ERROR : " + message, Toast.LENGTH_SHORT).show();
                        }
                    }
                });

        }else {
            Toast.makeText(this, "Same Email Address Added", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isEmailChanged() {
        if (!email.equals(updateEmail.getText().toString())){
            rootRef.child("Users").child(uId).child("email").setValue(updateEmail.getText().toString().trim());
            return true;
        }else{
            return false;
        }
    }

    private void UpdatePhoneNumber(){
        if (isPhoneNumberChanged()) {
            Toast.makeText(this, "Phone Number updated successfully", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(this, "Same Phone Number Added", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isPhoneNumberChanged() {
        if (!phoneNumber.equals(updatePhoneNumber.getText().toString())){
            rootRef.child("Users").child(uId).child("phoneNumber").setValue(updatePhoneNumber.getText().toString().trim());

            return true;
        }else{
            return false;
        }
    }

    private void VerifyEmail(){
        mUser.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()){
                    Toast.makeText(AboutActivity.this, "Verification Email sent to your Email inbox. Please Log In again after verifying", Toast.LENGTH_LONG).show();
                }else {
                    String message = Objects.requireNonNull(task.getException()).getMessage();
                    Toast.makeText(AboutActivity.this, "ERROR : " + message, Toast.LENGTH_LONG).show();
                }
            }
        });
    }
/*
    private void VerifyPhone(){
        //String phNumber = updatePhoneNumber.getText().toString().trim();

       // Intent intent = new Intent(AboutActivity.this, VerifyPhoneNumberActivity.class);
       // intent.putExtra("extraNumber", phNumber);
       // startActivity(intent);
    }
*/
    private void initialization() {
        updateUserName = findViewById(R.id.update_user_name);
        updateEmail = findViewById(R.id.update_email);
        updatePhoneNumber = findViewById(R.id.update_phone_number);
        buttonUpdateUserName = findViewById(R.id.button_update_userName);
        buttonUpdateEmail = findViewById(R.id.button_update_email);
        buttonUpdatePhone = findViewById(R.id.button_update_phone);
        verifyEmail = findViewById(R.id.text_view_verify_email);
        //verifyPhone = findViewById(R.id.text_view_verify_phone_number);
        buttonVerifyEmail = findViewById(R.id.button_verify_email);
        //buttonVerifyPhone = findViewById(R.id.button_verify_phone);
    }

}