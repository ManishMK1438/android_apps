package com.MYQ.myquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

public class SummaryActivity extends AppCompatActivity {
    private TextView textViewTotalQuestions;
    private TextView textViewCorrectAnswers;
    private TextView textViewIncorrectAnswers;
    private Button buttonExit;

    Animation fromBottom2;

    private InterstitialAd mInterstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        interstitialAd();

        Initialization();

        Intent intent = getIntent();
        int totalQuestion = intent.getIntExtra(String.valueOf(QuizActivity.TOTAL_QUESTIONS), 0);
        int correctAnswer = intent.getIntExtra(String.valueOf(QuizActivity.CORRECT_ANSWERS), 0);

        textViewTotalQuestions.setText("Total Questions :  " + totalQuestion);
        textViewCorrectAnswers.setText("Correct Answers :  " + correctAnswer);

        int incorrectAnswers = totalQuestion - correctAnswer;
        textViewIncorrectAnswers.setText("Incorrect Answers :  " + incorrectAnswers);


        buttonExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishQuiz();
            }
        });

        fromBottom2 = AnimationUtils.loadAnimation(this, R.anim.from_bottom_2);
        buttonExit.setAnimation(fromBottom2);
    }


    private void interstitialAd() {
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {

            }
        });
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-3940256099942544/1033173712");

        mInterstitialAd.loadAd(new AdRequest.Builder().build());

        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                // Load the next interstitial.
                mInterstitialAd.loadAd(new AdRequest.Builder().build());
            }

        });
    }


    private void finishQuiz() {
        Intent intent = new Intent(SummaryActivity.this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);

        if (mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
        } else {
            Log.d("TAG", "The interstitial wasn't loaded yet.");
        }
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(SummaryActivity.this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);

        if (mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
        } else {
            Log.d("TAG", "The interstitial wasn't loaded yet.");
        }
    }

    private void Initialization() {
        textViewTotalQuestions = findViewById(R.id.total_questions);
        textViewCorrectAnswers = findViewById(R.id.correct_answers);
        textViewIncorrectAnswers = findViewById(R.id.incorrect_answers);
        buttonExit = findViewById(R.id.exit);
    }
}
