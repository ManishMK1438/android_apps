package com.MYQ.myquiz;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseUser;

public class StartingScreenActivity extends AppCompatActivity {

    private Button buttonLogin;
    private Button buttonRegister;
    private FirebaseUser currentUser;
    Animation fromBottom;

    private long backPressedTime;
    private Toast backToast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_starting_screen);

        buttonLogin = findViewById(R.id.login_button);
        buttonRegister = findViewById(R.id.register_button);

        fromBottom = AnimationUtils.loadAnimation(this, R.anim.from_bottom);
        buttonLogin.setAnimation(fromBottom);
        buttonRegister.setAnimation(fromBottom);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginScreen();
            }
        });

        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerScreen();
            }
        });
    }

    private void registerScreen() {
        Intent registerIntent = new Intent(StartingScreenActivity.this, RegisterActivity.class);
        startActivity(registerIntent);
    }

    private void loginScreen() {
        Intent loginIntent = new Intent(StartingScreenActivity.this, LoginActivity.class);
        startActivity(loginIntent);
    }


}