package com.MYQ.myquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class ContactUsActivity extends AppCompatActivity {
    private TextView textViewEmailReport;
    private TextView textViewInstagramLink;
    private TextView textViewFacebookLink;

    private String addresses;
    private String subject;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);

        Initialization();

        textViewEmailReport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenGmail();
            }
        });


        textViewInstagramLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               OpenInstagram();
            }
        });


        textViewFacebookLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenFacebook("100008189374201");
            }
        });
    }

    private void OpenGmail() {
        try {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:" + "myquiz.learn@gmail.com")); // only email apps should handle this
            intent.putExtra(Intent.EXTRA_EMAIL, addresses);
            intent.putExtra(Intent.EXTRA_SUBJECT, subject);
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
            }
        } catch(Exception e) {
            Toast.makeText(ContactUsActivity.this, "Sorry...You don't have any mail app", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }

    }

    private void OpenInstagram() {
        try {
            Intent instaIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://instagram.com/_u/manish_mk3/"));
            instaIntent.setPackage("com.instagram.android");
                startActivity(instaIntent);
        }catch (ActivityNotFoundException e){
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://instagram.com/_u/manish_mk3/")));

        }
    }

    private void OpenFacebook(String id) {
        try {
            Intent fbIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("fb://page/" + id));
            fbIntent.setPackage("com.facebook.katana");
            startActivity(fbIntent);
        }catch (ActivityNotFoundException e){
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://facebook.com/" + id)));

        }
    }

    private void Initialization() {
        textViewEmailReport = findViewById(R.id.email_address);
        textViewInstagramLink = findViewById(R.id.developer_instagram);
        textViewFacebookLink = findViewById(R.id.developer_facebook);
    }
}